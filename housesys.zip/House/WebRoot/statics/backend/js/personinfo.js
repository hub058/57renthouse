function delfile(id) {
	$.ajax({
		type : "POST", //请求类型
		url : "delfile.json", //请求的url
		data : {
			id : id,
			flag : 'logo'
		}, //请求参数
		dataType : "json", //ajax接口（请求url）返回的数据类型
		success : function(data) { //data：返回数据（json对象）
			if(data.result == "success"){
				zeroModal.success("删除成功！");
				$("#uploadfile").show();
				$("#logoFile").html('');
			}else if(data.result == "failed"){
				alert("删除失败！");
			}s
		},
		error : function(data) { //当访问时候，404，500 等非200的错误状态码
			zeroModal.error('删除失败!');
		}
	});
}
$(function() {
	var portraitPicPath = $("#portraitPicPath").val();
	var id = $("#id").val();
	if (portraitPicPath == null || portraitPicPath == "") {
		$("#uploadfile").show();
	} else {
		$("#logoFile").append("<p><img  src=\"" + portraitPicPath + "?m=" + Math.random() + "\" width=\"90px;\"/> &nbsp;&nbsp;" +
			"<a href=\"\" onclick=\"delfile('" + id + "');\">删除</a></p>");
	}

});