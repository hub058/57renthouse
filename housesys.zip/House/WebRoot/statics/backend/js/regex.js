$(function() {
			layui.use([ 'form', 'upload' ], function() {
				var form = layui.form();
			});
			
			$("#repwd").blur(function() {
				if ($("#repwd").val() != '' && $("#newpwd").val() != '' && $("#repwd").val() != $("#newpwd").val()) {
					layer.msg('请保证两次输入的新密码一致！');
					$("#newpwd").val('');
					$("#repwd").val('');
				}
			});
			$(function() {
				$("#pic").click(function() {
					$("#upload").click(); //隐藏了input:file样式后，点击头像就可以本地上传
					$("#upload").on("change", function() {
						var objUrl = getObjectURL(this.files[0]); //获取图片的路径，该路径不是图片在本地的路径
						if (objUrl) {
							$("#pic").attr("src", objUrl); //将图片路径存入src中，显示出图片
						}
					});
				});
			});
	
	
			$("#email").blur(function() {
				var email = $("#email").val();
				var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/;
				if (email.match(reg) && $("#email").val() != '') {
					$.ajax({
						type : "GET",
						url : "emailexist.json",
						data : {
							email : email
						},
						dataType : "json",
						success : function(data) {
							if (data.result == "success") { //邮箱地址可以使用
								layer.msg("该邮箱地址可以使用！");
							} else if (data.result == "failed") { //邮箱地址已存在
								layer.alert("邮箱地址已存在,请换一个再试试吧！");
								$("#email").val("");
							}
						},
						error : function(data) {
							layer.msg("对不起，推荐失败");
						}
					});
				}else if(!email.match(reg) && $("#email").val() != ''){
					layer.msg("邮箱格式不正确，请重新输入！");
					$("#email").val("");
				}
			});
	
			$("#newpwd").blur(function() {
				var newpwd = $("#newpwd").val();
				var regr = /^(?:\d+|[a-zA-Z]+|[!@#$%^&*]+)$/
				var regz = /^(.{0,7}|[^0-9]*|[^A-Z]*|[^a-z]*|[a-zA-Z0-9]*)$/
				var regq = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,}$/
				if ((newpwd.length < 8 || newpwd.length > 16 )&& $("#newpwd").val() != '') {
					layer.msg("请输入8-16位密码");
					$("#newpwd").val("");
				} else if (newpwd.match(regr) && $("#newpwd").val() != '') {
					layer.msg("密码强度：弱");
				} else if (newpwd.match(regz) && $("#newpwd").val() != '') {
					layer.msg("密码强度：中");
				} else if (newpwd.match(regq) && $("#newpwd").val() != '') {
					layer.msg("密码强度：强");
				}
			});
			$("#phone").blur(function() {
				var phone = $("#phone").val();
				var reg = /^((1[3,5,8][0-9])|(14[5,7])|(17[0,6,7,8])|(19[7]))\d{8}$/;
				if (!phone.match(reg) && $("#phone").val() != '') {
					layer.msg("您输入的手机号码格式不正确");
					$("#phone").val("");
				}
			});
			$("#identity").blur(function() {
				var identity = $("#identity").val();
				var reg = /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/;
				if (!identity.match(reg) && $("#identity").val() != '') {
					layer.msg("您输入的身份证号码格式不正确");
					$("#identity").val("");
				}
			});
			$("#name").blur(function() {
				var name = $("#name").val();
				var reg = /^[\u4E00-\u9FA5A-Za-z]+$/;
				if (!name.match(reg) && $("#name").val() != '') {
					layer.msg("只能输入中文和英文");
					$("#identity").val("");
				}
			});
	
	
		});