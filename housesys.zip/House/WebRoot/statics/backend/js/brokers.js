layui.config({
	base : "js/"
}).use([ 'form', 'layer', 'jquery', 'laypage' ], function() {
	var form = layui.form(),
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		$ = layui.jquery;


	//批量删除
	$(".batchDel").click(function() {
		var $checkbox = $('.news_list tbody input[type="checkbox"][name="checked"]');
		var $checked = $('.news_list tbody input[type="checkbox"][name="checked"]:checked');
		var checkedList = new Array();
		$checked.each(function() {
			checkedList.push($(this).val());
		});
		if ($checkbox.is(":checked")) {
			layer.confirm('数据删除以后将无法恢复，是否确定删除？', {
				icon : 3,
				title : '温馨提示'
			}, function(index) {
				var index = layer.msg('删除中，请稍候', {
					icon : 16,
					time : false,
					shade : 0.8
				});
				setTimeout(function() {
					$.ajax({
						type : "GET",
						url : "delbrokers.json",
						data : {
							'delitems' : checkedList.toString()
						},
						dataType : "json",
						success : function(data) {
							if (data.result == "success") { //删除成功：移除删除行
								layer.msg("数据刪除成功！");
								window.location.reload();
							} else if (data.result == "failed") { //删除失败
								layer.msg("对不起，删除失败");
							}
						},
						error : function(data) {
							layer.msg("对不起，删除失败");
						}
					});
				}, 2000);
			})
		} else {
			layer.msg("请选择需要删除的经纪人");
		}
	})

	//全选
	form.on('checkbox(allChoose)', function(data) {
		var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]:not([name="show"])');
		child.each(function(index, item) {
			item.checked = data.elem.checked;
		});
		form.render('checkbox');
	});

	//通过判断文章是否全部选中来确定全选按钮是否选中
	form.on("checkbox(choose)", function(data) {
		var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]:not([name="show"])');
		var childChecked = $(data.elem).parents('table').find('tbody input[type="checkbox"]:not([name="show"]):checked')
		if (childChecked.length == child.length) {
			$(data.elem).parents('table').find('thead input#allChoose').get(0).checked = true;
		} else {
			$(data.elem).parents('table').find('thead input#allChoose').get(0).checked = false;
		}
		form.render('checkbox');
	})

	$("body").on("click", ".news_del", function() { //删除
		var obj = $(this);
		layer.confirm('删除该条数据无法恢复，是否确定删除？', {
			icon : 3,
			title : '温馨提示'
		}, function(index) {
			var index = layer.msg('删除中，请稍候', {
				icon : 16,
				time : false,
				shade : 0.8
			});
			setTimeout(function() {
				$.ajax({
					type : "GET",
					url : "delbroker.json",
					data : {
						bid : obj.attr("bid")
					},
					dataType : "json",
					success : function(data) {
						if (data.result == "success") { //删除成功：移除删除行
							layer.msg("刪除成功！");
							window.location.reload();
						} else if (data.result == "failed") { //删除失败
							layer.msg("对不起，删除失败");
						}
					},
					error : function(data) {
						layer.msg("对不起，删除失败");
					}
				});
			}, 2000);
		})
	});
	
})