layui.config({
	base : "js/"
}).use([ 'form', 'layer', 'jquery', 'laypage' ], function() {
	var form = layui.form(),
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		$ = layui.jquery;

	//加载页面数据
	var newsData = '';
	$.get("../../json/newsList.json", function(data) {
		var newArray = [];
		//单击首页“待审核文章”加载的信息
		if ($(".top_tab li.layui-this cite", parent.document).text() == "待委托文章") {
			if (window.sessionStorage.getItem("addNews")) {
				var addNews = window.sessionStorage.getItem("addNews");
				newsData = JSON.parse(addNews).concat(data);
			} else {
				newsData = data;
			}
			for (var i = 0; i < newsData.length; i++) {
				if (newsData[i].newsStatus == "待委托") {
					newArray.push(newsData[i]);
				}
			}
			newsData = newArray;
			newsList(newsData);
		} else { //正常加载信息
			newsData = data;
			if (window.sessionStorage.getItem("addNews")) {
				var addNews = window.sessionStorage.getItem("addNews");
				newsData = JSON.parse(addNews).concat(newsData);
			}
			//执行加载数据的方法
			newsList();
		}
	})

	//查询
	$(".search_btn").click(function() {
		var newArray = [];
		if ($(".search_input").val() != '') {
			var index = layer.msg('查询中，请稍候', {
				icon : 16,
				time : false,
				shade : 0.8
			});
			setTimeout(function() {
				$.ajax({
					url : "",
					type : "get",
					dataType : "json",
					success : function(data) {
						if (window.sessionStorage.getItem("addNews")) {
							var addNews = window.sessionStorage.getItem("addNews");
							newsData = JSON.parse(addNews).concat(data);
						} else {
							newsData = data;
						}
						for (var i = 0; i < newsData.length; i++) {
							var newsStr = newsData[i];
							var selectStr = $(".search_input").val();
							function changeStr(data) {
								var dataStr = '';
								var showNum = data.split(eval("/" + selectStr + "/ig")).length - 1;
								if (showNum > 1) {
									for (var j = 0; j < showNum; j++) {
										dataStr += data.split(eval("/" + selectStr + "/ig"))[j] + "<i style='color:#03c339;font-weight:bold;'>" + selectStr + "</i>";
									}
									dataStr += data.split(eval("/" + selectStr + "/ig"))[showNum];
									return dataStr;
								} else {
									dataStr = data.split(eval("/" + selectStr + "/ig"))[0] + "<i style='color:#03c339;font-weight:bold;'>" + selectStr + "</i>" + data.split(eval("/" + selectStr + "/ig"))[1];
									return dataStr;
								}
							}
							//文章标题
							if (newsStr.newsName.indexOf(selectStr) > -1) {
								newsStr["newsName"] = changeStr(newsStr.newsName);
							}
							//发布人
							if (newsStr.newsAuthor.indexOf(selectStr) > -1) {
								newsStr["newsAuthor"] = changeStr(newsStr.newsAuthor);
							}
							//审核状态
							if (newsStr.newsStatus.indexOf(selectStr) > -1) {
								newsStr["newsStatus"] = changeStr(newsStr.newsStatus);
							}
							//浏览权限
							if (newsStr.newsLook.indexOf(selectStr) > -1) {
								newsStr["newsLook"] = changeStr(newsStr.newsLook);
							}
							//发布时间
							if (newsStr.newsTime.indexOf(selectStr) > -1) {
								newsStr["newsTime"] = changeStr(newsStr.newsTime);
							}
							if (newsStr.newsName.indexOf(selectStr) > -1 || newsStr.newsAuthor.indexOf(selectStr) > -1 || newsStr.newsStatus.indexOf(selectStr) > -1 || newsStr.newsLook.indexOf(selectStr) > -1 || newsStr.newsTime.indexOf(selectStr) > -1) {
								newArray.push(newsStr);
							}
						}
						newsData = newArray;
						newsList(newsData);
					}
				})

				layer.close(index);
			}, 2000);
		} else {
			layer.msg("请输入需要查询的内容");
		}
	})

	//添加文章
	//改变窗口大小时，重置弹窗的高度，防止超出可视区域（如F12调出debug的操作）
	$(window).one("resize", function() {
		$(".newsAdd_btn").click(function() {
			var index = layui.layer.open({
				title : "添加房源",
				type : 2,
				content : "${pageContext.request.contextPath }/house/houseinfo",
				success : function(layero, index) {
					setTimeout(function() {
						layui.layer.tips('点击此处返回房源列表', '.layui-layer-setwin .layui-layer-close', {
							tips : 3
						});
					}, 500)
				}
			})
			layui.layer.full(index);
		})
	}).resize();

	//推荐房源
	$(".recommend").click(function() {
		var $checkbox = $(".news_list").find('tbody input[type="checkbox"]:not([name="show"])');
		var $checked = $('.news_list tbody input[type="checkbox"][name="checked"]:checked');
		var checkedList = new Array();
		$checked.each(function() {
			var obj = $(this);
			var statusid = obj.attr("statusid");
			if (statusid == 2 || statusid == 3) {
				checkedList.push($(this).val());
			}
		});
		if ($checked.length != checkedList.length) {
			layer.msg("只能选择处于发布状态的房源，请重试!");
		} else {
			if ($checkbox.is(":checked")) {
				var index = layer.msg('推荐中，请稍候', {
					icon : 16,
					time : false,
					shade : 0.8
				});
				setTimeout(function() {
					layer.close(index);
					$.ajax({
						type : "GET",
						url : "recommend.json",
						data : {
							'recitems' : checkedList.toString()
						},
						dataType : "json",
						success : function(data) {
							if (data.result == "success") { //删除成功：移除删除行
								layer.msg("已在首页展示！");
								window.location.reload();
							} else if (data.result == "failed") { //删除失败
								layer.msg("对不起，推荐失败");
							}
						},
						error : function(data) {
							layer.msg("对不起，推荐失败");
						}
					});
				}, 2000);
			} else {
				layer.msg("请选择需要推荐的房源");
			}
		}
	})

	//批量受委
	$(".audit_btn").click(function() {
		var $checkbox = $('.news_list tbody input[type="checkbox"][name="checked"]');
		var $checked = $('.news_list tbody input[type="checkbox"][name="checked"]:checked');
		var checkedList = new Array();
		$checked.each(function() {
			checkedList.push($(this).val());
		});
		if ($checkbox.is(":checked")) {
			layer.confirm('接受委托后将无法取消，是否确定接受？', {
				icon : 3,
				title : '温馨提示'
			}, function(index) {
				var index = layer.msg('接受中，请稍候', {
					icon : 16,
					time : false,
					shade : 0.8
				});
				setTimeout(function() {
					$.ajax({
						type : "GET",
						url : "receivemore.json",
						data : {
							'recitems' : checkedList.toString()
						},
						dataType : "json",
						success : function(data) {
							if (data.result == "success") { //删除成功：移除删除行
								layer.msg("批量接受委托成功！");
								window.location.reload();
							} else if (data.result == "failed") { //删除失败
								layer.msg("对不起，接受委托失败");
							}
						},
						error : function(data) {
							layer.msg("对不起，接受委托失败");
						}
					});
				}, 2000);
			})
		} else {
			layer.msg("请选择需要接收委托的房源");
		}
	})

	//批量删除
	$(".batchDel").click(function() {
		var $checkbox = $('.news_list tbody input[type="checkbox"][name="checked"]');
		var $checked = $('.news_list tbody input[type="checkbox"][name="checked"]:checked');
		var checkedList = new Array();
		$checked.each(function() {
			checkedList.push($(this).val());
		});
		if ($checkbox.is(":checked")) {
			layer.confirm('数据删除以后将无法恢复，是否确定删除？', {
				icon : 3,
				title : '温馨提示'
			}, function(index) {
				var index = layer.msg('删除中，请稍候', {
					icon : 16,
					time : false,
					shade : 0.8
				});
				setTimeout(function() {
					$.ajax({
						type : "GET",
						url : "deletehousemore.json",
						data : {
							'delitems' : checkedList.toString()
						},
						dataType : "json",
						success : function(data) {
							if (data.result == "success") { //删除成功：移除删除行
								layer.msg("数据刪除成功！");
								window.location.reload();
							} else if (data.result == "failed") { //删除失败
								layer.msg("对不起，删除失败");
							}
						},
						error : function(data) {
							layer.msg("对不起，删除失败");
						}
					});
				}, 2000);
			})
		} else {
			layer.msg("请选择需要删除的房源");
		}
	})

	//全选
	form.on('checkbox(allChoose)', function(data) {
		var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]:not([name="show"])');
		child.each(function(index, item) {
			item.checked = data.elem.checked;
		});
		form.render('checkbox');
	});

	//通过判断文章是否全部选中来确定全选按钮是否选中
	form.on("checkbox(choose)", function(data) {
		var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]:not([name="show"])');
		var childChecked = $(data.elem).parents('table').find('tbody input[type="checkbox"]:not([name="show"]):checked')
		if (childChecked.length == child.length) {
			$(data.elem).parents('table').find('thead input#allChoose').get(0).checked = true;
		} else {
			$(data.elem).parents('table').find('thead input#allChoose').get(0).checked = false;
		}
		form.render('checkbox');
	})

	//是否展示
	form.on('switch(isShow)', function(data) {
		var index = layer.msg('修改中，请稍候', {
			icon : 16,
			time : false,
			shade : 0.8
		});
		setTimeout(function() {
			layer.close(index);
		}, 2000);
		var id = data.elem.attributes['data'].value;
		var state = data.elem.checked;
		showchange(id, state);
	})
	function showchange(id, state) {
		$.ajax({
			type : "GET", //请求类型
			url : "showchange.json", //请求的url
			data : {
				id : id,
				flag : state
			}, //请求参数
			dataType : "json", //ajax接口（请求url）返回的数据类型
			success : function(data) { //data：返回数据（json对象）
				if (data.result == 'success') {
					setTimeout(function() {
						layer.msg("状态修改成功！");
						window.location.reload();
					}, 2000);
				}
			},
			error : function(data) { //当访问时候，404，500 等非200的错误状态码
				zeroModal.error('状态修改失败!');
			}
		});
	}
	//操作
	$("body").on("click", ".news_edit", function() { //编辑
		layer.alert('您点击了文章编辑按钮，由于是纯静态页面，所以暂时不存在编辑内容，后期会添加，敬请谅解。。。', {
			icon : 6,
			title : '文章编辑'
		});

	})
	//完成订单
	$("body").on("click", ".house_achieve", function() { //完成
		var obj = $(this);
		var id = obj.attr("houseid");
		var index = layer.msg('执行中，请稍候', {
			icon : 16,
			time : false,
			shade : 0.8
		});
		setTimeout(function() {
			layer.close(index);
		}, 2000);
		achieve(id);
	});
	function achieve(id) {
		$.ajax({
			type : "GET", //请求类型
			url : "achieve.json", //请求的url
			data : {
				hid : id
			}, //请求参数
			dataType : "json", //ajax接口（请求url）返回的数据类型
			success : function(data) { //data：返回数据（json对象）
				if (data.result == 'success') {
					setTimeout(function() {
						layer.msg("谢谢您的付出，辛苦了！");
						window.location.reload();
					}, 2000);
				}
			},
			error : function(data) { //当访问时候，404，500 等非200的错误状态码
				zeroModal.error('状态修改失败!');
			}
		});
	}
	$("body").on("click", ".news_del", function() { //删除
		var obj = $(this);
		layer.confirm('删除该条数据无法恢复，是否确定删除？', {
			icon : 3,
			title : '温馨提示'
		}, function(index) {
			var index = layer.msg('删除中，请稍候', {
				icon : 16,
				time : false,
				shade : 0.8
			});
			setTimeout(function() {
				$.ajax({
					type : "GET",
					url : "deletehouse.json",
					data : {
						id : obj.attr("houseid")
					},
					dataType : "json",
					success : function(data) {
						if (data.result == "success") { //删除成功：移除删除行
							layer.msg("刪除成功！");
							obj.parents("tr").remove();
						} else if (data.result == "failed") { //删除失败
							layer.msg("对不起，删除失败");
						}
					},
					error : function(data) {
						layer.msg("对不起，删除失败");
					}
				});
			}, 2000);
		})
	});
	$("body").on("click", ".return_client", function() { //客户回访
		var tradersName = $("#tradersName").val();
		var tradersPhone = $("#tradersPhone").val();
		layer.alert("姓名：" + tradersName+"<br/>电话：" + tradersPhone);
	});
	$("body").on("click", ".news_collect", function() { //删除
		var obj = $(this);
		layer.confirm('接受委托以后将无法取消，是否确定接受？', {
			icon : 3,
			title : '温馨提示'
		}, function(index) {
			var index = layer.msg('接受中，请稍候', {
				icon : 16,
				time : false,
				shade : 0.8
			});
			setTimeout(function() {
				$.ajax({
					type : "GET",
					url : "receive.json",
					data : {
						hid : obj.attr("houseid")
					},
					dataType : "json",
					success : function(data) {
						if (data.result == "success") { //删除成功：移除删除行
							layer.msg("接受委托成功！");
							window.location.reload();
						} else if (data.result == "failed") { //删除失败
							layer.msg("对不起，接受委托失败");
						}
					},
					error : function(data) {
						layer.msg("对不起，接受委托失败");
					}
				});
			}, 2000);
		})
	});
	
})