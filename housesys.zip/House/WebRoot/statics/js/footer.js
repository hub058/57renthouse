$(function() {
	document.getElementById("span").style.display = "none";
	var path = $("#path").val();
	$.idcode.setCode();
	$("#Txtidcode").blur(function() {
		var IsBy = $.idcode.validateCode();
		if (IsBy == false&&$("#Txtidcode").val()!='') {
			document.getElementById("span").style.display = "block";
			$("#Txtidcode").val("");
		}
	});
	$("#Txtidcode").click(function() {
		document.getElementById("span").style.display = "none";
	});
	$("#slider").responsiveSlides({
		auto : true,
		nav : false,
		speed : 500,
		namespace : "callbacks",
		pager : true,
	});
	var hint = $("#hint").val();
	if (hint == 'error') {
		alert('邮箱地址或密码错误!');
	} else if (hint == 'errorcode') {
		alert("手机验证码错误！");
	} else if (hint == "forgotsuccess") {
		alert("修改成功！");
	} else if (hint == "success") {
		alert("注册成功！");
	} else if (hint == "difference") {
		alert("这和之前输入的手机号不一致！");
	}

	$(".btnSendCode").click(function() {
		var reg = /^1[3|4|5|7|8][0-9]{9}$/
		var tel;
		if ($("#tel").val() != "") {
			tel = $("#tel").val();
		}
		if ($("#phone").val() != "") {
			tel = $("#phone").val();
		}
		if ($("#tel_login").val() != "") {
			tel = $("#tel_login").val();
		}
		if (!tel.match(reg)) {
			alert("请输入正确格式的手机号码");
			$("#tel").val("");
			$("#phone").val("");
		} else {
			var InterValObj; //timer变量，控制时间
			var count = 60; //间隔函数，1秒执行
			var curCount; //当前剩余秒数
			var code = ""; //验证码
			var codeLength = 6; //验证码长度
			function sendMessage() {
				curCount = count;
				//设置button效果，开始计时
				$(".btnSendCode").attr("disabled", "true");
				$(".btnSendCode").val(+curCount + "秒再获取");
				InterValObj = window.setInterval(SetRemainTime, 1000); //启动计时器，1秒执行一次
				//向后台发送处理数据
				$.ajax({
					type : "POST",
					url : path +"/user/message.json",
					data : {
						'mobile' : tel
					},
					dataType : "json",
					success : function(data) {}
				});
			}
			/* 面试题JS代码是自上而下一行一行执行 */
			sendMessage();

			//timer处理函数
			function SetRemainTime() {
				if (curCount == 0) {
					window.clearInterval(InterValObj); //停止计时器
					$(".btnSendCode").removeAttr("disabled"); //启用按钮
					$(".btnSendCode").val("重新发送验证码");
					code = ""; //清除验证码。如果不清除，过时间后，输入收到的验证码依然有效
				} else {
					curCount--;
					$(".btnSendCode").val(+curCount + "秒再获取");
				}
			}
		}
	});

	$("#email").blur(function() {
		var email = $("#email").val();
		var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/;
		if (email.match(reg) && $("#email").val() != '') {
			$.ajax({
				type : "GET",
				url : path+"/backend/emailexist.json",
				data : {
					'email' : email
				},
				dataType : "json",
				success : function(data) {
					if (data.result == "failed") { //邮箱地址已存在
						alert("邮箱地址已存在,请换一个再试试吧！");
						$("#email").val("");
					}
				},
				error : function(data) {
					layer.msg("对不起，推荐失败");
				}
			});
		} else if (!email.match(reg) && $("#email").val() != '') {
			alert("邮箱格式不正确，请重新输入！");
			$("#email").val("");
		}
	});

	$("#repwd").blur(function() {
		if ($("#repwd").val() != '' && $("#pwd").val() != '' && $("#repwd").val() != $("#pwd").val()) {
			alert('请保证两次输入的新密码一致！');
			$("#pwd").val('');
			$("#repwd").val('');
		}
	});
	$("#tel_login").blur(function() {
		var tel = $("#tel_login").val();
		var reg = /^1[3|4|5|7|8][0-9]{9}$/
		if (tel.match(reg) && $("#tel_login").val() != '') {
			$.ajax({
				type : "GET",
				url : path+"/user/telexist.json",
				data : {
					'tel' : tel
				},
				dataType : "json",
				success : function(data) {
					if (data.result == "none") {
						alert("该手机号未注册！");
						$("#tel_login").val("");
					}
				},
			});
		} else if (!tel.match(reg) && $("#tel_login").val() != '') {
			alert("手机格式不正确，请重新输入！");
			$("#tel_login").val("");
		}
	});
	$("#tel").blur(function() {
		var tel = $("#tel").val();
		var reg = /^1[3|4|5|7|8][0-9]{9}$/
			if (tel.match(reg) && $("#tel").val() != '') {
				$.ajax({
					type : "GET",
					url : path+"/user/telexist.json",
					data : {
						'tel' : tel
					},
					dataType : "json",
					success : function(data) {
						if (data.result == "none") {
							alert("该手机号未注册！");
							$("#tel").val("");
						}
					},
				});
			} else if (!tel.match(reg) && $("#tel").val() != '') {
				alert("手机格式不正确，请重新输入！");
				$("#tel").val("");
			}
	});

	$("#rpwd").blur(function() {
		var pwd = $("#rpwd").val();
		if ((pwd.length < 8 || pwd.length > 16) && $("#rpwd").val() != '') {
			alert("请输入8-16位密码");
			$("#rpwd").val("");
		}
	});
	$("#pwd").blur(function() {
		var pwd = $("#pwd").val();
		if ((pwd.length < 8 || pwd.length > 16) && $("#pwd").val() != '') {
			alert("请输入8-16位密码");
			$("#pwd").val("");
		}
	});
	$("#phone").blur(function() {
		var tel = $("#phone").val();
		var reg = /^1[3|4|5|7|8][0-9]{9}$/
		if (tel.match(reg) && $("#phone").val() != '') {
			$.ajax({
				type : "GET",
				url : path+"/user/telexist.json",
				data : {
					'tel' : tel
				},
				dataType : "json",
				success : function(data) {
					if (data.result == "exist") {
						alert("该手机号已存在！");
						$("#phone").val("");
					}
				},
			});
		} else if (!tel.match(reg) && $("#phone").val() != '') {
			alert("手机格式不正确，请重新输入！");
			$("#phone").val("");
		}
	});

});