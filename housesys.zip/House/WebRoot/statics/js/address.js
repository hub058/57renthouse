$("#queryProvinces").change(function(){
	var queryProvinces = $("#queryProvinces").val();
	if(queryProvinces != '' && queryProvinces != null){
		$.ajax({
			type:"GET",//请求类型
			url:"cityList.json",//请求的url
			data:{provincecode:queryProvinces},//请求参数
			dataType:"json",//ajax接口（请求url）返回的数据类型
			success:function(data){//data：返回数据（json对象）
				$("#queryCity").html("");
				var options = "<option value=\"\">请选择</option>";
				for(var i = 0; i < data.length; i++){
					options += "<option value=\""+data[i].code+"\">"+data[i].name+"</option>";
				}
				$("#queryCity").html(options);
			},
			error:function(data){//当访问时候，404，500 等非200的错误状态码
				alert("加载城市失败！");
			}
		});
	}else{
		$("#queryCity").html("");
		var options = "<option value=\"\">请选择</option>";
		$("#queryCity").html(options);
	}
	$("#queryArea").html("");
	var options = "<option value=\"\">请选择</option>";
	$("#queryArea").html(options);
});

$("#queryCity").change(function(){
	var queryCity = $("#queryCity").val();
	if(queryCity != '' && queryCity != null){
		$.ajax({
			type:"GET",//请求类型
			url:"areaList.json",//请求的url
			data:{citycode:queryCity},//请求参数
			dataType:"json",//ajax接口（请求url）返回的数据类型
			success:function(data){//data：返回数据（json对象）
				$("#queryArea").html("");
				var options = "<option value=\"\">请选择</option>";
				for(var i = 0; i < data.length; i++){
					options += "<option value=\""+data[i].code+"\">"+data[i].name+"</option>";
				}
				$("#queryArea").html(options);
			},
			error:function(data){//当访问时候，404，500 等非200的错误状态码
				alert("加载区县失败！");
			}
		});
	}else{
		$("#queryCity").html("");
		var options = "<option value=\"\">请选择</option>";
		$("#queryCity").html(options);
	}
	$("#queryArea").html("");
	var options = "<option value=\"\">请选择</option>";
	$("#queryArea").html(options);
});

