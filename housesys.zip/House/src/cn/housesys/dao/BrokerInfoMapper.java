package cn.housesys.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.housesys.pojo.BrokerInfo;

public interface BrokerInfoMapper {

	public List<BrokerInfo> findall(@Param("name") String name, @Param("roleId") Integer roleId,
			@Param("from") Integer from, @Param("pageSize") Integer pageSize);

	public int insertBroker(BrokerInfo brokerInfo);

	public int deleteBrokerById(Integer id);

	public int changeBrokerInfo(BrokerInfo brokerInfo);

	public BrokerInfo getBrokerInfo(@Param("email") String email, @Param("password") String password,
			@Param("id") Integer id, @Param("roleId") Integer roleId, @Param("phone") String phone);

	public int getBrokerCount(@Param("name") String name, @Param("roleId") Integer roleId);

}
