package cn.housesys.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.housesys.pojo.AddressArea;
import cn.housesys.pojo.AddressCity;
import cn.housesys.pojo.AddressProvince;

public interface AddressMapper {

	public List<AddressProvince> getProvinceList();

	public List<AddressCity> getCityListByProCode(@Param("provincecode") String provincecode);

	public List<AddressArea> getAreaListByCityCode(@Param("citycode") String citycode);
}
