package cn.housesys.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.housesys.pojo.HouseInfo;
import cn.housesys.pojo.HousePicture;
import cn.housesys.pojo.HouseProperty;
import cn.housesys.pojo.HouseStatus;
import cn.housesys.pojo.HouseType;

public interface HouseMapper {

	public void houseInfoAdd(HouseInfo houseInfo);

	public void housePropertyAdd(HouseProperty houseProperty);

	public void housePictureAdd(HousePicture housePicture);

	public List<HouseInfo> getHouseInfos(@Param("house") HouseInfo houseInfo, @Param("street") String street,
			@Param("from") Integer from, @Param("pageSize") Integer pageSize);

	public HouseInfo getHouseInfoById(@Param("id") Integer id);

	public HouseProperty getHousePropertyByHouseId(@Param("houseId") Integer houseId);

	public List<HousePicture> getHousePicturesByHouseId(@Param("houseId") Integer houseId, @Param("from") Integer from,
			@Param("pageSize") Integer pageSize);

	public Integer getHouseInfoCount(HouseInfo houseInfo);

	public List<HouseStatus> getHouseStatus();

	public List<HouseType> getHouseType();

	public List<HouseInfo> getHouseInfosByLimit(@Param("statusId") Integer statusId,
			@Param("brokerId") Integer brokerId, @Param("ownerId") Integer ownerId,
			@Param("isRecommend") Integer isRecommend, @Param("from") Integer from,
			@Param("pageSize") Integer pageSize);

	public void changeHouseInfoById(HouseInfo houseInfo);

	public void deleteHouseInfoById(@Param("id") Integer id);

	public void deleteHousePropertyById(@Param("id") Integer id);

	public void deleteHousePictureById(@Param("id") Integer id);

	public Integer getHouseMaxId();

	public void changeHousePropertyById(HouseProperty houseProperty);

	public Integer getHousePictureCountByHid(@Param("hid") Integer hid);

	public List<Integer> getHouseIdByOwnerId(@Param("ownerId") Integer ownerId);

}
