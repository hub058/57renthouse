package cn.housesys.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.housesys.pojo.UserInfo;

public interface UserMapper {
	public UserInfo getUserInfo(@Param("email") String email, @Param("password") String password,
			@Param("id") Integer id,@Param("tel")String tel);

	public void getRegist(UserInfo userInfo);

	public int getUserCount(@Param("isToday") boolean isToday, @Param("name") String name,
			@Param("status") Integer status);

	public int changeUserInfo(UserInfo userInfo);

	public List<UserInfo> getUsersIsToday(@Param("isToday") boolean isToday, @Param("name") String name,
			@Param("status") Integer status, @Param("from") Integer from, @Param("pageSize") Integer pageSize);

	public void delUserById(@Param("uid") Integer id);

}
