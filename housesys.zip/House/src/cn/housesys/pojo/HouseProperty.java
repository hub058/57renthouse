package cn.housesys.pojo;

public class HouseProperty {

	private Integer id; // 主鍵
	private Integer houseId; // 房屋外鍵
	private String renovation; // 裝修
	private String ac; // 空调
	private String equipment; // 设备
	private String bathroomDescription;// 浴室特点
	private String bedroomFeatures;// 卧室特点
	private String street;// 街道
	private String diningArea;// 餐饮区
	private String enclosure;// 围栏
	private String buildingStructure;// 建筑结构
	private String floor;// 地板
	private String heating;// 供暖
	private String garage;// 车库
	private String orientations;// 朝向
	private Integer storey;// 楼层
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getHouseId() {
		return houseId;
	}
	public void setHouseId(Integer houseId) {
		this.houseId = houseId;
	}
	public String getRenovation() {
		return renovation;
	}
	public void setRenovation(String renovation) {
		this.renovation = renovation;
	}
	public String getAc() {
		return ac;
	}
	public void setAc(String ac) {
		this.ac = ac;
	}
	public String getEquipment() {
		return equipment;
	}
	public void setEquipment(String equipment) {
		this.equipment = equipment;
	}
	public String getBathroomDescription() {
		return bathroomDescription;
	}
	public void setBathroomDescription(String bathroomDescription) {
		this.bathroomDescription = bathroomDescription;
	}
	public String getBedroomFeatures() {
		return bedroomFeatures;
	}
	public void setBedroomFeatures(String bedroomFeatures) {
		this.bedroomFeatures = bedroomFeatures;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getDiningArea() {
		return diningArea;
	}
	public void setDiningArea(String diningArea) {
		this.diningArea = diningArea;
	}
	public String getEnclosure() {
		return enclosure;
	}
	public void setEnclosure(String enclosure) {
		this.enclosure = enclosure;
	}
	public String getBuildingStructure() {
		return buildingStructure;
	}
	public void setBuildingStructure(String buildingStructure) {
		this.buildingStructure = buildingStructure;
	}
	public String getFloor() {
		return floor;
	}
	public void setFloor(String floor) {
		this.floor = floor;
	}
	public String getHeating() {
		return heating;
	}
	public void setHeating(String heating) {
		this.heating = heating;
	}
	public String getGarage() {
		return garage;
	}
	public void setGarage(String garage) {
		this.garage = garage;
	}
	public String getOrientations() {
		return orientations;
	}
	public void setOrientations(String orientations) {
		this.orientations = orientations;
	}
	public Integer getStorey() {
		return storey;
	}
	public void setStorey(Integer storey) {
		this.storey = storey;
	}


}
