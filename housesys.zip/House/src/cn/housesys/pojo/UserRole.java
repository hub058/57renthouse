package cn.housesys.pojo;

public class UserRole {
	private Integer id; //主键
	private String roleName; //权限名称 
}
