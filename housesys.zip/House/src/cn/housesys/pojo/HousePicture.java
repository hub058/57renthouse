package cn.housesys.pojo;

public class HousePicture {

	private Integer id; // 主键
	private Integer houseId;// 房屋ID
	private String housePicPath;// 房屋照片url路径
	private String houseLocPath;// 房屋照片的服务器存储路径
	private Integer isCover;

	public Integer getIsCover() {
		return isCover;
	}

	public void setIsCover(Integer isCover) {
		this.isCover = isCover;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getHouseId() {
		return houseId;
	}

	public void setHouseId(Integer houseId) {
		this.houseId = houseId;
	}

	public String getHousePicPath() {
		return housePicPath;
	}

	public void setHousePicPath(String housePicPath) {
		this.housePicPath = housePicPath;
	}

	public String getHouseLocPath() {
		return houseLocPath;
	}

	public void setHouseLocPath(String houseLocPath) {
		this.houseLocPath = houseLocPath;
	}

}
