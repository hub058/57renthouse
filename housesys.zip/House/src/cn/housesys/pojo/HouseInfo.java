package cn.housesys.pojo;

import java.util.Date;

public class HouseInfo {
	private Integer id; // 主键
	private Integer ownerId; // 房主Id
	private String province; // 省份code
	private String provinceName;// 省份名称
	private String city; // 城市
	private String cityName;// 城市名称
	private String area; // 区县
	private String areaName;// 区县名称
	private String housing; // 小区
	private float price; // 价格
	private Integer typeId; // 房屋类型Id
	private String typeName;// 房屋类型名称
	private Integer specifiedStatusId; // 指定上架状态Id
	private String specifiedStatusName;
	private Integer statusId; // 房屋当前状态Id
	private String statusName;// 房屋当前状态名称
	private String describe;// 描述
	private float acreage; // 面积
	private Integer parlourNum;// 客厅数量
	private Integer roomNum; // 房间数量
	private Integer garageNum;// 车库数量
	private Integer brokerId;// 经纪人Id
	private String tradersName;// 交易人姓名
	private String tradersPhone;// 交易人电话
	private Date creationDate;// 创建时间
	private Date addDate;// 上架时间
	private Date transactionDate;// 交易时间
	private String housePicPath;// 房屋照片
	private Integer isRecommend;//是否热推
	private String videoPicPath;//视频本地路径
	private String videoLocPath;//视频服务器路径

	
	public String getVideoPicPath() {
		return videoPicPath;
	}

	public void setVideoPicPath(String videoPicPath) {
		this.videoPicPath = videoPicPath;
	}

	public String getVideoLocPath() {
		return videoLocPath;
	}

	public void setVideoLocPath(String videoLocPath) {
		this.videoLocPath = videoLocPath;
	}

	public String getTradersName() {
		return tradersName;
	}

	public void setTradersName(String tradersName) {
		this.tradersName = tradersName;
	}

	public String getTradersPhone() {
		return tradersPhone;
	}

	public void setTradersPhone(String tradersPhone) {
		this.tradersPhone = tradersPhone;
	}


	public Integer getIsRecommend() {
		return isRecommend;
	}

	public void setIsRecommend(Integer isRecommend) {
		this.isRecommend = isRecommend;
	}

	public String getSpecifiedStatusName() {
		return specifiedStatusName;
	}

	public void setSpecifiedStatusName(String specifiedStatusName) {
		this.specifiedStatusName = specifiedStatusName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Integer ownerId) {
		this.ownerId = ownerId;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public String getHousing() {
		return housing;
	}

	public void setHousing(String housing) {
		this.housing = housing;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public Integer getSpecifiedStatusId() {
		return specifiedStatusId;
	}

	public void setSpecifiedStatusId(Integer specifiedStatusId) {
		this.specifiedStatusId = specifiedStatusId;
	}

	public Integer getStatusId() {
		return statusId;
	}

	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public String getDescribe() {
		return describe;
	}

	public void setDescribe(String describe) {
		this.describe = describe;
	}

	public float getAcreage() {
		return acreage;
	}

	public void setAcreage(float acreage) {
		this.acreage = acreage;
	}

	public Integer getParlourNum() {
		return parlourNum;
	}

	public void setParlourNum(Integer parlourNum) {
		this.parlourNum = parlourNum;
	}

	public Integer getRoomNum() {
		return roomNum;
	}

	public void setRoomNum(Integer roomNum) {
		this.roomNum = roomNum;
	}

	public Integer getGarageNum() {
		return garageNum;
	}

	public void setGarageNum(Integer garageNum) {
		this.garageNum = garageNum;
	}

	public Integer getBrokerId() {
		return brokerId;
	}

	public void setBrokerId(Integer brokerId) {
		this.brokerId = brokerId;
	}


	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getAddDate() {
		return addDate;
	}

	public void setAddDate(Date addDate) {
		this.addDate = addDate;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public String getHousePicPath() {
		return housePicPath;
	}

	public void setHousePicPath(String housePicPath) {
		this.housePicPath = housePicPath;
	}

}
