package cn.housesys.tools;

public class Constants {
	public final static String USER = "userInfoSession";
	public final static String BROKER = "brokerSession";
	public final static String SYS_MESSAGE = "message";
	public final static int pageSize = 6;
	public final static String FILEUPLOAD_ERROR_1 = " * APK信息不完整！";
	public final static String FILEUPLOAD_ERROR_2 = " * 上传失败！";
	public final static String FILEUPLOAD_ERROR_3 = " * 上传文件格式不正确！";
	public final static String FILEUPLOAD_ERROR_4 = " * 上传文件过大！";
}
