package cn.housesys.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import cn.housesys.pojo.BrokerInfo;
import cn.housesys.pojo.UserInfo;
import cn.housesys.tools.Constants;


public class SysInterceptor extends HandlerInterceptorAdapter{

	

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
			Object handler) throws Exception {
		HttpSession session=request.getSession();
		
		UserInfo user= (UserInfo) session.getAttribute(Constants.USER);
		BrokerInfo broker = (BrokerInfo) session.getAttribute(Constants.BROKER);
		
		if (null!=user) {
			return true;
		}
		if (null!=broker) {
			return true;
		}
		
		response.sendRedirect(request.getContextPath()+"/404.jsp");
		return false;
	}
	
}
