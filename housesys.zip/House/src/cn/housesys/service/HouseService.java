package cn.housesys.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.housesys.pojo.HouseInfo;
import cn.housesys.pojo.HousePicture;
import cn.housesys.pojo.HouseProperty;
import cn.housesys.pojo.HouseStatus;
import cn.housesys.pojo.HouseType;

public interface HouseService {

	public void houseInfoAdd(HouseInfo houseInfo) throws Exception;

	public void housePropertyAdd(HouseProperty houseProperty) throws Exception;

	public void housePictureAdd(HousePicture housePicture) throws Exception;

	public List<HouseInfo> getHouseInfos(HouseInfo houseInfo, String street, Integer from, Integer pageSize)
			throws Exception;

	public HouseInfo getHouseInfoById(Integer id) throws Exception;

	public HouseProperty getHouseProperty(Integer houseId) throws Exception;

	public List<HousePicture> getHousePictures(Integer houseId, Integer from, Integer pageSize) throws Exception;

	public Integer getHouseInfoCount(HouseInfo houseInfo) throws Exception;

	public List<HouseStatus> getHouseStatus() throws Exception;

	public List<HouseType> getHouseType() throws Exception;

	public List<HouseInfo> getHouseInfosByLimit(Integer statusId, Integer brokerId, Integer ownerId,
			Integer isRecommend, Integer from, Integer pageSize) throws Exception;

	public void changeHouseInfoById(HouseInfo houseInfo) throws Exception;

	public void deleteHouseInfoById(Integer id) throws Exception;

	public void deleteHousePropertyById(Integer id) throws Exception;

	public void deleteHousePictureById(Integer id) throws Exception;

	public Integer getHouseMaxId() throws Exception;

	public void changeHousePropertyById(HouseProperty houseProperty) throws Exception;

	public Integer getHousePictureCountByHid(Integer hid) throws Exception;

	public List<Integer> getHouseIdByOwnerId(Integer ownerId) throws Exception;
}
