package cn.housesys.service;

import java.util.List;

import cn.housesys.pojo.AddressArea;
import cn.housesys.pojo.AddressCity;
import cn.housesys.pojo.AddressProvince;

public interface AddressService {

	public List<AddressProvince> getProvinceList() throws Exception;

	public List<AddressCity> getCityListByProCode(String provincecode) throws Exception;

	public List<AddressArea> getAreaListByCityCode(String citycode) throws Exception;
}
