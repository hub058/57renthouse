package cn.housesys.service;

import java.util.List;

import cn.housesys.pojo.BrokerInfo;

public interface BrokerInfoService {

	List<BrokerInfo> findall(String name, Integer roleId, Integer from, Integer pageSize);

	public boolean insertBroker(BrokerInfo brokerInfo) throws Exception;

	public int deleteBrokerById(Integer id);

	public int changeBrokerInfo(BrokerInfo brokerInfo);

	public BrokerInfo getBrokerInfo(String email, String password, Integer id, Integer roleId,String phone) throws Exception;

	public int getBrokerCount(String name, Integer roleId) throws Exception;
}
