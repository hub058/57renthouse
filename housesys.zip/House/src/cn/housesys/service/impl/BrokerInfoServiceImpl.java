package cn.housesys.service.impl;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.housesys.dao.BrokerInfoMapper;
import cn.housesys.pojo.BrokerInfo;
import cn.housesys.service.BrokerInfoService;

@Service("brokerInfoService")
public class BrokerInfoServiceImpl implements BrokerInfoService {
	@Autowired
	private BrokerInfoMapper brokerinfomapper;

	@Override
	public List<BrokerInfo> findall(String name,Integer roleId,Integer from, Integer pageSize) {
		List<BrokerInfo> list = brokerinfomapper.findall(name, roleId, (from-1)*pageSize, pageSize);
		return list;
	}

	@Override
	public boolean insertBroker(BrokerInfo brokerInfo) {
		int result = brokerinfomapper.insertBroker(brokerInfo);
		if (result > 0) {
			return true;
		}
		return false;
	}

	@Override
	public int deleteBrokerById(Integer id) {
		return brokerinfomapper.deleteBrokerById(id);
	}


	@Override
	public BrokerInfo getBrokerInfo(String email, String password, Integer id, Integer roleId,String phone) throws Exception {

		return brokerinfomapper.getBrokerInfo(email, password, id, roleId,phone);
	}

	@Override
	public int getBrokerCount(String name,Integer roleId) throws Exception {
		return brokerinfomapper.getBrokerCount(name, roleId);
	}

	@Override
	public int changeBrokerInfo(BrokerInfo brokerInfo) {
		return brokerinfomapper.changeBrokerInfo(brokerInfo);
	}

}
