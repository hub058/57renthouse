package cn.housesys.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

import cn.housesys.dao.HouseMapper;
import cn.housesys.pojo.HouseInfo;
import cn.housesys.pojo.HousePicture;
import cn.housesys.pojo.HouseProperty;
import cn.housesys.pojo.HouseStatus;
import cn.housesys.pojo.HouseType;
import cn.housesys.service.HouseService;

@Service("houseService")
public class HouseServiceImpl implements HouseService {

	@Resource
	private HouseMapper houseMapper;

	@Override
	public void houseInfoAdd(HouseInfo houseInfo) throws Exception {
		houseMapper.houseInfoAdd(houseInfo);
	}

	@Override
	public void housePropertyAdd(HouseProperty houseProperty) throws Exception {
		houseMapper.housePropertyAdd(houseProperty);
	}

	@Override
	public void housePictureAdd(HousePicture housePicture) throws Exception {
		houseMapper.housePictureAdd(housePicture);
	}

	@Override
	public List<HouseInfo> getHouseInfos(HouseInfo houseInfo, String street, Integer from, Integer pageSize)
			throws Exception {
		return houseMapper.getHouseInfos(houseInfo, street, (from - 1) * pageSize, pageSize);
	}

	@Override
	public HouseInfo getHouseInfoById(Integer id) throws Exception {
		return houseMapper.getHouseInfoById(id);
	}

	@Override
	public HouseProperty getHouseProperty(Integer houseId) throws Exception {
		return houseMapper.getHousePropertyByHouseId(houseId);
	}

	@Override
	public List<HousePicture> getHousePictures(Integer houseId, Integer from, Integer pageSize) throws Exception {
		if (from != null && pageSize != null) {
			return houseMapper.getHousePicturesByHouseId(houseId, (from - 1), pageSize);
		} else {
			return houseMapper.getHousePicturesByHouseId(houseId, null, null);
		}
	}

	@Override
	public Integer getHouseInfoCount(HouseInfo houseInfo) {
		return houseMapper.getHouseInfoCount(houseInfo);
	}

	@Override
	public List<HouseStatus> getHouseStatus() {
		return houseMapper.getHouseStatus();
	}

	@Override
	public List<HouseType> getHouseType() {
		return houseMapper.getHouseType();
	}

	@Override
	public List<HouseInfo> getHouseInfosByLimit(Integer statusId, Integer brokerId, Integer ownerId,
			Integer isRecommend, Integer from, Integer pageSize) throws Exception {
		return houseMapper.getHouseInfosByLimit(statusId, brokerId, ownerId, isRecommend, (from - 1) * pageSize,
				pageSize);
	}

	@Override
	public void changeHouseInfoById(HouseInfo houseInfo) throws Exception {
		houseMapper.changeHouseInfoById(houseInfo);
	}

	@Override
	public void deleteHouseInfoById(Integer id) throws Exception {
		houseMapper.deleteHouseInfoById(id);

	}

	@Override
	public void deleteHousePropertyById(Integer id) throws Exception {
		houseMapper.deleteHousePropertyById(id);
	}

	@Override
	public void deleteHousePictureById(Integer id) throws Exception {
		houseMapper.deleteHousePictureById(id);
	}

	@Override
	public Integer getHouseMaxId() throws Exception {
		return houseMapper.getHouseMaxId();
	}

	@Override
	public void changeHousePropertyById(HouseProperty houseProperty) throws Exception {
		houseMapper.changeHousePropertyById(houseProperty);
	}

	@Override
	public Integer getHousePictureCountByHid(Integer hid) throws Exception {
		return houseMapper.getHousePictureCountByHid(hid);
	}

	@Override
	public List<Integer> getHouseIdByOwnerId(Integer ownerId) throws Exception {
		return houseMapper.getHouseIdByOwnerId(ownerId);
	}

}
