package cn.housesys.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.housesys.dao.UserMapper;
import cn.housesys.pojo.UserInfo;
import cn.housesys.service.UserService;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Resource
	private UserMapper userMapper;

	@Override
	public UserInfo login(String email, String password) {
		return userMapper.getUserInfo(email, password, null, null);
	}

	@Override
	public void regist(UserInfo userInfo) {
		userMapper.getRegist(userInfo);
	}

	@Override
	public int changeUserInfo(UserInfo userInfo) throws Exception {
		return userMapper.changeUserInfo(userInfo);
	}

	@Override
	public UserInfo getUserInfoById(int id) {
		return userMapper.getUserInfo(null, null, id, null);
	}

	@Override
	public void delUserById(Integer id) throws Exception {
		userMapper.delUserById(id);
	}

	@Override
	public int getUserCount(boolean isToday, String name, Integer status) throws Exception {
		return userMapper.getUserCount(isToday, name, status);
	}

	@Override
	public List<UserInfo> getUsers(boolean isToday, String name, Integer status, Integer from, Integer pageSize)
			throws Exception {
		return userMapper.getUsersIsToday(isToday, name, status, (from - 1) * pageSize, pageSize);
	}

	@Override
	public UserInfo getUserInfoByTel(String tel) throws Exception {
		return userMapper.getUserInfo(null, null, null, tel);
	}

}
