package cn.housesys.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.housesys.dao.AddressMapper;
import cn.housesys.pojo.AddressArea;
import cn.housesys.pojo.AddressCity;
import cn.housesys.pojo.AddressProvince;
import cn.housesys.service.AddressService;

@Service("addressService")
public class AddressServiceImpl implements AddressService {

	@Resource
	private AddressMapper addressMapper;

	@Override
	public List<AddressProvince> getProvinceList() {
		return addressMapper.getProvinceList();
	}

	@Override
	public List<AddressCity> getCityListByProCode(String provincecode) throws Exception {
		return addressMapper.getCityListByProCode(provincecode);
	}

	@Override
	public List<AddressArea> getAreaListByCityCode(String citycode) throws Exception {
		return addressMapper.getAreaListByCityCode(citycode);
	}

}
