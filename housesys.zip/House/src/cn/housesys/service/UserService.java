package cn.housesys.service;

import java.util.List;

import cn.housesys.pojo.UserInfo;

public interface UserService {
	public UserInfo login(String email, String password);

	public UserInfo getUserInfoById(int id) throws Exception;

	public UserInfo getUserInfoByTel(String tel) throws Exception;

	public void regist(UserInfo userInfo) throws Exception;

	public int getUserCount(boolean isToday, String name, Integer status) throws Exception;

	public int changeUserInfo(UserInfo userInfo) throws Exception;

	public List<UserInfo> getUsers(boolean isToday, String name, Integer status, Integer from, Integer pageSize)
			throws Exception;

	public void delUserById(Integer id) throws Exception;
}
