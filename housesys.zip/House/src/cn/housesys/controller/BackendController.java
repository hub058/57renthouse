package cn.housesys.controller;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONArray;

import cn.housesys.pojo.AddressArea;
import cn.housesys.pojo.AddressCity;
import cn.housesys.pojo.AddressProvince;
import cn.housesys.pojo.BrokerInfo;
import cn.housesys.pojo.HouseInfo;
import cn.housesys.pojo.HousePicture;
import cn.housesys.pojo.HouseProperty;
import cn.housesys.pojo.HouseStatus;
import cn.housesys.pojo.HouseType;
import cn.housesys.pojo.UserInfo;
import cn.housesys.service.AddressService;
import cn.housesys.service.BrokerInfoService;
import cn.housesys.service.HouseService;
import cn.housesys.service.UserService;
import cn.housesys.tools.Constants;
import cn.housesys.tools.PageSupport;

@Controller
@RequestMapping("/backend")
public class BackendController {

	@Resource
	private UserService userService;
	@Resource
	private BrokerInfoService brokerInfoService;
	@Resource
	private HouseService houseService;
	@Resource
	private AddressService addressService;

	@RequestMapping(value = "/tobackend", method = RequestMethod.GET)
	public String toBackend(@RequestParam("action") String action, HttpSession session, HttpServletRequest request,
			Model model) {
		UserInfo user = (UserInfo) session.getAttribute(Constants.USER);
		BrokerInfo broker = (BrokerInfo) session.getAttribute(Constants.BROKER);
		if (action.trim().equals("main")) {
			model.addAttribute("action", "main");
		} else if (action.trim().equals("changepwd")) {
			model.addAttribute("action", "changepwd");
		} else if (action.trim().equals("personinfo")) {
			model.addAttribute("action", "personinfo");
		} else if (action.trim().equals("users")) {
			model.addAttribute("action", "users");
		} else if (action.trim().equals("brokers")) {
			model.addAttribute("action", "brokers");
		} else if (action.trim().equals("houses")) {
			model.addAttribute("action", "houses");
		}
		return "backend/index";
	}

	@RequestMapping(value = "/changepwd", method = RequestMethod.GET)
	public String changePwd() {
		return "backend/changepwd";
	}

	@RequestMapping(value = "/changepwd", method = RequestMethod.POST)
	public String changePwd(@RequestParam("newpwd") String newpwd, @RequestParam("oldpwd") String oldpwd,
			HttpSession session, HttpServletRequest request) {
		UserInfo user = (UserInfo) session.getAttribute(Constants.USER);
		BrokerInfo broker = (BrokerInfo) session.getAttribute(Constants.BROKER);
		try {
			if (user != null) {
				if (oldpwd.trim().equals(user.getPassword())) {
					user.setPassword(newpwd);
					user.setModifyDate(new Date());
					userService.changeUserInfo(user);
					request.setAttribute("hint", "success");
				} else {
					request.setAttribute("hint", "error");
				}

			} else if (broker != null) {
				if (oldpwd.trim().equals(broker.getPassword())) {
					broker.setPassword(newpwd);
					brokerInfoService.changeBrokerInfo(broker);
					request.setAttribute("hint", "success");
				} else {
					request.setAttribute("hint", "error");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "backend/changepwd";
	}

	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public String toMain(Model model, HttpSession session) {
		HouseInfo houseInfo = null;
		UserInfo user = (UserInfo) session.getAttribute(Constants.USER);
		BrokerInfo broker = (BrokerInfo) session.getAttribute(Constants.BROKER);
		List<HouseInfo> houseInfos = null;
		try {
			if (user != null) {
				if (user.getRoleId() == 1) {
					int userCount = userService.getUserCount(false, null, null);
					int userCountByToday = userService.getUserCount(true, null, null);
					int userCountOnline = userService.getUserCount(false, null, 1);
					int houseCount = houseService.getHouseInfoCount(houseInfo);
					int brokerCount = brokerInfoService.getBrokerCount(null, null);
					model.addAttribute("userCount", userCount);
					model.addAttribute("userCountByToday", userCountByToday);
					model.addAttribute("userCountOnline", userCountOnline);
					model.addAttribute("houseCount", houseCount);
					model.addAttribute("brokerCount", brokerCount);
				} else {
					houseInfo = new HouseInfo();
					houseInfo.setOwnerId(user.getId());
					int houseCountByOwnerId = houseService.getHouseInfoCount(houseInfo);
					houseInfo.setStatusId(4);
					int houseCountByOwnerIdAchieve = houseService.getHouseInfoCount(houseInfo);
					houseInfo.setStatusId(3);
					int houseCountByOwnerIdRent = houseService.getHouseInfoCount(houseInfo);
					houseInfo.setStatusId(2);
					int houseCountByOwnerIdSell = houseService.getHouseInfoCount(houseInfo);
					houseInfo.setStatusId(1);
					int houseCountByOwnerIdUnchecked = houseService.getHouseInfoCount(houseInfo);
					model.addAttribute("houseCountByOwnerId", houseCountByOwnerId);
					model.addAttribute("houseCountByOwnerIdAchieve", houseCountByOwnerIdAchieve);
					model.addAttribute("houseCountByOwnerIdRent", houseCountByOwnerIdRent);
					model.addAttribute("houseCountByOwnerIdSell", houseCountByOwnerIdSell);
					model.addAttribute("houseCountByOwnerIdUnchecked", houseCountByOwnerIdUnchecked);
				}
			} else if (broker != null) {
				houseInfo = new HouseInfo();
				houseInfo.setBrokerId(broker.getId());
				int houseCountByBrokerId = houseService.getHouseInfoCount(houseInfo);
				houseInfo.setStatusId(3);
				int houseCountByBrokerIdRent = houseService.getHouseInfoCount(houseInfo);
				houseInfo.setStatusId(2);
				int houseCountByBrokerIdSell = houseService.getHouseInfoCount(houseInfo);
				model.addAttribute("houseCountByBrokerId", houseCountByBrokerId);
				model.addAttribute("houseCountByBrokerIdRent", houseCountByBrokerIdRent);
				model.addAttribute("houseCountByBrokerIdSell", houseCountByBrokerIdSell);
			}
			houseInfos = houseService.getHouseInfosByLimit(null, null, null, null, 1, 5);
			model.addAttribute("houseInfos", houseInfos);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "backend/main";
	}

	@RequestMapping(value = "/personinfo", method = RequestMethod.GET)
	public String getUserInfoById(@RequestParam(value = "uid", required = false) Integer uid,
			@RequestParam(value = "bid", required = false) Integer bid, Model model) {
		UserInfo user = null;
		BrokerInfo broker = null;
		try {
			if (uid != null) {
				user = userService.getUserInfoById(uid);
				model.addAttribute("user", user);
			} else if (bid != null) {
				broker = brokerInfoService.getBrokerInfo(null, null, bid, null, null);
				model.addAttribute("broker", broker);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "backend/personinfo";
	}

	@RequestMapping(value = "/changebrokerinfo", method = RequestMethod.POST)
	public String changepersonfinfo(@ModelAttribute BrokerInfo brokerInfo, @RequestParam("attach") MultipartFile attach,
			HttpServletRequest request, HttpSession session, Model model) {
		if (attach != null && attach.getSize() > 0) {
			// 原始文件名字
			String originalFilename = attach.getOriginalFilename();
			int maxSize = 500 * 1024;
			// 判断文件是否是图片类型
			String extension = FilenameUtils.getExtension(originalFilename);
			if (extension.equalsIgnoreCase("jpg") || extension.equalsIgnoreCase("png")
					|| extension.equalsIgnoreCase("bmp")) {
				long size = attach.getSize();
				if (size <= maxSize) {
					String realPath = request.getServletContext().getRealPath("/statics/uploadfiles");
					// 重新命名文件
					String newFilename = System.currentTimeMillis() + new Random().nextInt(50000000) + "_Person."
							+ extension;
					// 创建新的文件
					File dscFile = new File(realPath, newFilename);

					// 上传文件
					try {
						// 如果目标文件不存在就创建文件
						if (!dscFile.exists()) {
							dscFile.createNewFile();
						}
						attach.transferTo(dscFile);
						// 补全图片的路径到实体类
						brokerInfo.setPortraitLocPath(realPath + File.separator + newFilename);
						brokerInfo.setPortraitPicPath(
								request.getServletContext().getContextPath() + "/statics/uploadfiles/" + newFilename);
					} catch (Exception e) {
						request.setAttribute("hint", "error");
						e.printStackTrace();
					}
				} else {
					// 图片太大
					request.setAttribute("hint", "error0");
				}

			} else {
				// 不是图片
				request.setAttribute("hint", "error1");
			}
		}
		try {
			brokerInfoService.changeBrokerInfo(brokerInfo);
			brokerInfo = brokerInfoService.getBrokerInfo(null, null, brokerInfo.getId(), null, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		BrokerInfo broker = (BrokerInfo) session.getAttribute(Constants.BROKER);
		if (broker != null && broker.getId() == brokerInfo.getId()) {
			session.setAttribute(Constants.BROKER, brokerInfo);
		}
		model.addAttribute("broker", brokerInfo);
		request.setAttribute("hint", "success");
		return "backend/personinfo";
	}

	@RequestMapping(value = "/changeuserinfo", method = RequestMethod.POST)
	public String changepersonfinfo(@ModelAttribute UserInfo userInfo, HttpSession session, HttpServletRequest request,
			Model model) {
		userInfo.setModifyDate(new Date());
		try {
			userService.changeUserInfo(userInfo);
			userInfo = userService.getUserInfoById(userInfo.getId());
			UserInfo user = (UserInfo) session.getAttribute(Constants.USER);
			if (user != null && user.getId() == userInfo.getId()) {
				session.setAttribute(Constants.USER, userInfo);
			}
			model.addAttribute("user", userInfo);
			request.setAttribute("hint", "success");
		} catch (Exception e) {
			request.setAttribute("hint", "error");
			e.printStackTrace();
		}
		return "backend/personinfo";
	}

	@RequestMapping(value = "/delfile.json", method = RequestMethod.POST)
	@ResponseBody
	public Object delFile(@RequestParam(value = "id", required = false) Integer id, @RequestParam("flag") String flag,
			HttpSession session, Model model) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		String fileLocPath = null;
		if (id == null || ("").equals(id)) {
			resultMap.put("result", "failed");
		} else {
			try {
				if (flag.trim().equals("logo")) {
					BrokerInfo brokerInfo = brokerInfoService.getBrokerInfo(null, null, id, null, null);
					fileLocPath = brokerInfo.getPortraitLocPath();
					File file = new File(fileLocPath);
					if (file.exists()) {
						file.delete();
					}
					brokerInfo.setPortraitPicPath(null);
					brokerInfo.setPortraitLocPath(null);
					brokerInfoService.changeBrokerInfo(brokerInfo);
					model.addAttribute("broker", brokerInfo);
					resultMap.put("result", "success");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return JSONArray.toJSONString(resultMap);
	}

	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public String getUsers(@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "isToday", required = false, defaultValue = "false") Boolean isToday,
			@RequestParam(value = "status", required = false) Integer status,
			@RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex, Model model) {
		try {
			Integer userCount = userService.getUserCount(isToday, name, status);
			Integer pageSize = Constants.pageSize;
			PageSupport pageSupport = new PageSupport();
			pageSupport.setCurrentPageNo(pageIndex);
			pageSupport.setPageSize(pageSize);
			pageSupport.setTotalCount(userCount);
			List<UserInfo> userInfos = userService.getUsers(isToday, name, status, pageIndex, pageSize);
			model.addAttribute("userlist", userInfos);
			model.addAttribute("pages", pageSupport);
			model.addAttribute("name", name);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "backend/userlist";
	}

	@RequestMapping(value = "/brokers", method = RequestMethod.GET)
	public String getBrokers(@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "roleId", required = false) Integer roleId,
			@RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex, Model model) {
		try {
			Integer brokerCount = brokerInfoService.getBrokerCount(name, roleId);
			Integer pageSize = Constants.pageSize;
			PageSupport pageSupport = new PageSupport();
			pageSupport.setCurrentPageNo(pageIndex);
			pageSupport.setPageSize(pageSize);
			pageSupport.setTotalCount(brokerCount);
			List<BrokerInfo> brokerInfos = brokerInfoService.findall(name, roleId, pageIndex, pageSize);
			model.addAttribute("brokerlist", brokerInfos);
			model.addAttribute("pages", pageSupport);
			model.addAttribute("name", name);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "backend/brokerlist";
	}

	@RequestMapping(value = "/manageradd", method = RequestMethod.GET)
	public String manageradd() {
		return "backend/manageradd";
	}

	@RequestMapping(value = "/manageradd", method = RequestMethod.POST)
	public String manageradd(@ModelAttribute UserInfo user, HttpServletRequest request) {
		user.setCreationDate(new Date());
		user.setRoleId(1);
		user.setStatus(0);
		try {
			userService.regist(user);
			request.setAttribute("hint", "success");
		} catch (Exception e) {
			request.setAttribute("hint", "error");
			e.printStackTrace();
		}
		return "backend/manageradd";
	}

	@RequestMapping(value = "/brokeradd", method = RequestMethod.GET)
	public String brokeradd() {
		return "backend/brokeradd";
	}

	@RequestMapping(value = "/brokeradd", method = RequestMethod.POST)
	public String brokeradd(@ModelAttribute BrokerInfo broker, HttpServletRequest request, MultipartFile portrait) {
		broker.setRoleId(1);
		broker.setResults(0);
		if (portrait != null && portrait.getSize() > 0) {
			// 原始文件名字
			String originalFilename = portrait.getOriginalFilename();
			int maxSize = 500 * 1024;
			// 判断文件是否是图片类型
			String extension = FilenameUtils.getExtension(originalFilename);
			if (extension.equalsIgnoreCase("jpg") || extension.equalsIgnoreCase("png")
					|| extension.equalsIgnoreCase("bmp")) {
				long size = portrait.getSize();
				if (size <= maxSize) {
					String realPath = request.getServletContext().getRealPath("/statics/uploadfiles");
					// 重新命名文件
					String newFilename = System.currentTimeMillis() + new Random().nextInt(50000000) + "_Person."
							+ extension;
					// 创建新的文件
					File dscFile = new File(realPath, newFilename);

					// 上传文件
					try {
						// 如果目标文件不存在就创建文件
						if (!dscFile.exists()) {
							dscFile.createNewFile();
						}
						portrait.transferTo(dscFile);
						// 补全图片的路径到实体类
						broker.setPortraitLocPath(realPath + File.separator + newFilename);
						broker.setPortraitPicPath(
								request.getServletContext().getContextPath() + "/statics/uploadfiles/" + newFilename);
						if (broker.getDescription() == null || broker.getDescription() != "") {
							broker.setDescription("既然选择了远方，便只顾风雨兼程；路漫漫其修远兮，吾将上下而求索");
						}
						if (brokerInfoService.insertBroker(broker)) {
							request.setAttribute("hint", "success");
						}
					} catch (Exception e) {
						request.setAttribute("hint", "error");
						e.printStackTrace();
					}
				} else {
					// 图片太大
					request.setAttribute("hint", "error0");
				}

			} else {
				// 不是图片
				request.setAttribute("hint", "error1");
			}
		}
		return "backend/brokeradd";
	}

	@RequestMapping(value = "/houses", method = RequestMethod.GET)
	public String getHouseInfos(@RequestParam(value = "result", required = false) String result,
			@RequestParam(value = "status", required = false) Integer status,
			@RequestParam(value = "pageIndex", required = false, defaultValue = "1") String pageIndex,
			HttpSession session, Model model, HttpServletRequest request) {
		UserInfo user = (UserInfo) session.getAttribute(Constants.USER);
		BrokerInfo broker = (BrokerInfo) session.getAttribute(Constants.BROKER);
		List<HouseInfo> houseInfoList = null;
		HouseInfo houseInfo = null;
		Integer pageSize = Constants.pageSize;
		Integer houseCount = null;
		PageSupport pageSupport = new PageSupport();
		try {
			if (user != null) {
				if (user.getRoleId() == 1) {
					houseCount = houseService.getHouseInfoCount(null);
					houseInfoList = houseService.getHouseInfosByLimit(status, null, null, null,
							Integer.valueOf(pageIndex), pageSize);
				} else {
					houseInfo = new HouseInfo();
					houseInfo.setOwnerId(user.getId());
					houseInfo.setStatusId(status);
					houseCount = houseService.getHouseInfoCount(houseInfo);
					houseInfoList = houseService.getHouseInfosByLimit(status, null, user.getId(), null,
							Integer.valueOf(pageIndex), pageSize);
				}
			} else if (broker != null) {
				houseInfo = new HouseInfo();
				houseInfo.setStatusId(status);
				houseInfo.setBrokerId(broker.getId());
				houseCount = houseService.getHouseInfoCount(houseInfo);
				houseInfoList = houseService.getHouseInfosByLimit(status, broker.getId(), null, null,
						Integer.valueOf(pageIndex), pageSize);
			}
			pageSupport.setCurrentPageNo(Integer.valueOf(pageIndex));
			pageSupport.setPageSize(pageSize);
			pageSupport.setTotalCount(houseCount);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (result != null) {
			if (result.trim().equals("addsuccess")) {
				request.setAttribute("hint", "addsuccess");
			} else if (result.trim().equals("traderssuccess")) {
				request.setAttribute("hint", "traderssuccess");
			}
		}
		model.addAttribute("houses", houseInfoList);
		model.addAttribute("pages", pageSupport);
		model.addAttribute("status", status);
		return "backend/houselist";
	}

	@RequestMapping(value = "/showchange.json", method = RequestMethod.GET)
	@ResponseBody
	public Object checkchange(@RequestParam(value = "id", required = false) String id,
			@RequestParam("flag") String flag) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		if (id == null || ("").equals(id)) {
			resultMap.put("result", "failed");
		} else {
			try {
				HouseInfo houseInfo = houseService.getHouseInfoById(Integer.valueOf(id));
				if (flag.trim().equals("true")) {
					houseInfo.setStatusId(houseInfo.getSpecifiedStatusId());
					houseInfo.setAddDate(new Date());
					houseService.changeHouseInfoById(houseInfo);
					resultMap.put("result", "success");
				} else if (flag.trim().equals("false")) {
					houseInfo.setStatusId(5);
					houseService.changeHouseInfoById(houseInfo);
					resultMap.put("result", "success");
				}
			} catch (Exception e) {
				resultMap.put("result", "failed");
				e.printStackTrace();
			}
		}
		return JSONArray.toJSONString(resultMap);
	}

	@RequestMapping(value = "/emailexist.json", method = RequestMethod.GET)
	@ResponseBody
	public Object emailExist(@RequestParam(value = "email", required = false) String email) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		if (email == null || ("").equals(email)) {
			resultMap.put("result", "failed");
		} else {
			try {
				BrokerInfo brokerInfo = brokerInfoService.getBrokerInfo(email, null, null, null, null);
				UserInfo user = userService.login(email, null);
				if (brokerInfo == null && user == null) {
					resultMap.put("result", "success");
				} else {
					resultMap.put("result", "failed");
				}

			} catch (Exception e) {
				resultMap.put("result", "failed");
				e.printStackTrace();
			}
		}
		return JSONArray.toJSONString(resultMap);
	}

	@RequestMapping(value = "/deletehouse.json", method = RequestMethod.GET)
	@ResponseBody
	public String deleteHouse(@Param("hid") Integer id) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		String fileLocPath = null;
		if (id == null || id.equals("")) {
			resultMap.put("result", "failed");
		} else {
			try {
				List<HousePicture> housePictures = houseService.getHousePictures(id, null, null);
				for (HousePicture housePicture : housePictures) {
					fileLocPath = housePicture.getHouseLocPath();
					File file = new File(fileLocPath);
					if (file.exists()) {
						file.delete();
					}
				}
				houseService.deleteHousePropertyById(id);
				houseService.deleteHousePictureById(id);
				houseService.deleteHouseInfoById(id);
				resultMap.put("result", "success");
			} catch (Exception e) {
				resultMap.put("result", "failed");
				e.printStackTrace();
			}
		}
		return JSONArray.toJSONString(resultMap);
	}

	@RequestMapping(value = "/deletehousemore.json", method = RequestMethod.GET)
	@ResponseBody
	public String deleteHouseMore(HttpServletRequest request) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		String items = request.getParameter("delitems");
		String fileLocPath = null;
		if (items == null || items == "") {
			resultMap.put("result", "failed");
		} else {
			String[] item = items.split(",");
			try {
				for (int i = 0; i < item.length; i++) {
					List<HousePicture> housePictures = houseService.getHousePictures(Integer.parseInt(item[i]), null,
							null);
					for (HousePicture housePicture : housePictures) {
						fileLocPath = housePicture.getHouseLocPath();
						File file = new File(fileLocPath);
						if (file.exists()) {
							file.delete();
						}
					}
					houseService.deleteHousePropertyById(Integer.parseInt(item[i]));
					houseService.deleteHousePictureById(Integer.parseInt(item[i]));
					houseService.deleteHouseInfoById(Integer.parseInt(item[i]));

				}
				resultMap.put("result", "success");
			} catch (Exception e) {
				resultMap.put("result", "failed");
				e.printStackTrace();
			}
		}
		return JSONArray.toJSONString(resultMap);
	}

	@RequestMapping(value = "/receive.json", method = RequestMethod.GET)
	@ResponseBody
	public String receive(@RequestParam("hid") Integer hid, HttpServletRequest request, HttpSession session) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		BrokerInfo broker = (BrokerInfo) session.getAttribute(Constants.BROKER);
		HouseInfo houseInfo = null;
		try {
			houseInfo = houseService.getHouseInfoById(hid);
			houseInfo.setStatusId(houseInfo.getSpecifiedStatusId());
			houseInfo.setBrokerId(broker.getId());
			houseInfo.setAddDate(new Date());
			houseService.changeHouseInfoById(houseInfo);
			resultMap.put("result", "success");
		} catch (Exception e) {
			resultMap.put("result", "failed");
			e.printStackTrace();
		}
		return JSONArray.toJSONString(resultMap);
	}

	@RequestMapping(value = "/receivemore.json", method = RequestMethod.GET)
	@ResponseBody
	public String receiveMore(HttpServletRequest request, HttpSession session) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		BrokerInfo broker = (BrokerInfo) session.getAttribute(Constants.BROKER);
		String items = request.getParameter("recitems");
		if (items == null || items == "") {
			resultMap.put("result", "failed");
		} else {
			String[] item = items.split(",");
			try {
				for (int i = 0; i < item.length; i++) {
					HouseInfo houseInfo = houseService.getHouseInfoById(Integer.parseInt(item[i]));
					if (houseInfo.getStatusId() == 1) {
						houseInfo.setStatusId(houseInfo.getSpecifiedStatusId());
						houseInfo.setBrokerId(broker.getId());
						houseInfo.setAddDate(new Date());
						houseService.changeHouseInfoById(houseInfo);
					}
				}
				resultMap.put("result", "success");
			} catch (Exception e) {
				resultMap.put("result", "failed");
				e.printStackTrace();
			}
		}
		return JSONArray.toJSONString(resultMap);
	}

	@RequestMapping(value = "/achieve.json", method = RequestMethod.GET)
	@ResponseBody
	public String achieve(@RequestParam("hid") Integer hid, HttpSession session) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		BrokerInfo brokerInfo = (BrokerInfo) session.getAttribute(Constants.BROKER);
		UserInfo user = (UserInfo) session.getAttribute(Constants.USER);
		try {
			HouseInfo houseInfo = houseService.getHouseInfoById(hid);
			houseInfo.setTransactionDate(new Date());
			if (brokerInfo != null) {
				houseInfo.setStatusId(6);
				Integer results = brokerInfo.getResults() + 1;
				brokerInfo.setResults(results);
				if (results >= 15) {
					brokerInfo.setRoleId(2);
				} else if (results >= 50) {
					brokerInfo.setRoleId(3);
				} else if (results >= 100) {
					brokerInfo.setRoleId(4);
				} else if (results >= 200) {
					brokerInfo.setRoleId(5);
				}
				brokerInfoService.changeBrokerInfo(brokerInfo);
			} else {
				houseInfo.setStatusId(4);
				houseInfo.setIsRecommend(0);
				houseInfo.setTransactionDate(new Date());
			}
			houseService.changeHouseInfoById(houseInfo);
			resultMap.put("result", "success");
		} catch (Exception e) {
			resultMap.put("result", "failed");
			e.printStackTrace();
		}
		return JSONArray.toJSONString(resultMap);
	}

	@RequestMapping(value = "/recommend.json", method = RequestMethod.GET)
	@ResponseBody
	public String recommend(HttpServletRequest request) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		String items = request.getParameter("recitems");
		List<HouseInfo> houseInfos = null;
		if (items == null || items == "") {
			resultMap.put("result", "failed");
		} else {
			String[] item = items.split(",");
			try {
				houseInfos = houseService.getHouseInfosByLimit(null, null, null, 1, 1, item.length);
				if (houseInfos.size() > 0) {
					for (HouseInfo house : houseInfos) {
						house.setIsRecommend(0);
						houseService.changeHouseInfoById(house);
					}
				}
				for (int i = 0; i < item.length; i++) {
					HouseInfo houseInfo = houseService.getHouseInfoById(Integer.parseInt(item[i]));
					houseInfo.setIsRecommend(1);
					houseService.changeHouseInfoById(houseInfo);
				}
				resultMap.put("result", "success");
			} catch (Exception e) {
				resultMap.put("result", "failed");
				e.printStackTrace();
			}
		}
		return JSONArray.toJSONString(resultMap);
	}

	@RequestMapping(value = "/houseinfo", method = RequestMethod.POST)
	public String addHouseInfo(@ModelAttribute HouseInfo houseInfo,
			@RequestParam(value = "queryMw", required = false) String queryMw,
			@RequestParam(value = "querySskf", required = false) String querySskf,
			@RequestParam(value = "queryWy", required = false) String queryWy,
			@RequestParam(value = "queryJzx", required = false) String queryJzx,
			@RequestParam(value = "queryDtf", required = false) String queryDtf,
			@RequestParam(value = "queryJtbl", required = false) String queryJtbl,
			@RequestParam(value = "queryHjym", required = false) String queryHjym,
			@RequestParam(value = "queryShbg", required = false) String queryShbg, MultipartFile video,
			HttpSession session, HttpServletRequest request) {

		if (video != null && video.getSize() > 0) {
			// 原始文件名字
			String originalFilename = video.getOriginalFilename();
			// 判断文件是否是图片类型
			String extension = FilenameUtils.getExtension(originalFilename);
			if (extension.equalsIgnoreCase("mp4")) {
				String realPath = request.getServletContext().getRealPath("/statics/video");
				// 重新命名文件
				String newFilename = System.currentTimeMillis() + new Random().nextInt(50000000) + "_Person."
						+ extension;
				// 创建新的文件
				File dscFile = new File(realPath, newFilename);

				// 上传文件
				try {
					// 如果目标文件不存在就创建文件
					if (!dscFile.exists()) {
						dscFile.createNewFile();
					}
					video.transferTo(dscFile);
					// 补全视频的路径到实体类
					houseInfo.setVideoLocPath(realPath + File.separator + newFilename);
					houseInfo.setVideoPicPath(
							request.getServletContext().getContextPath() + "/statics/video/" + newFilename);
				} catch (Exception e) {
					request.setAttribute("hint", "error");
					e.printStackTrace();
				}

			} else {
				request.setAttribute("hint", "error1");
			}
		}
		StringBuffer describe = new StringBuffer();
		if (queryMw != null) {
			describe.append("满五,");
		}
		if (querySskf != null) {
			describe.append("随时看房,");
		}
		if (queryWy != null) {
			describe.append("唯一,");
		}
		if (queryJzx != null) {
			describe.append("精装修,");
		}
		if (queryDtf != null) {
			describe.append("地铁房,");
		}
		if (queryJtbl != null) {
			describe.append("交通便利,");
		}
		if (queryHjym != null) {
			describe.append("环境优美,");
		}
		if (queryShbg != null) {
			describe.append("适合办公,");
		}
		describe.append(
				houseInfo.getRoomNum() + "室" + houseInfo.getParlourNum() + "厅" + houseInfo.getGarageNum() + "车位");
		UserInfo userInfo = (UserInfo) session.getAttribute(Constants.USER);
		houseInfo.setOwnerId(userInfo.getId());
		houseInfo.setStatusId(1);
		houseInfo.setIsRecommend(0);
		houseInfo.setDescribe(describe.toString());
		houseInfo.setCreationDate(new Date());
		try {
			houseService.houseInfoAdd(houseInfo);
			request.setAttribute("hint", "successinfo");
			request.setAttribute("action", "add");
		} catch (Exception e) {
			request.setAttribute("hint", "error");
			e.printStackTrace();
			return "backend/houseinfo";
		}
		return "backend/houseproperty";
	}

	@RequestMapping(value = "/houseproperty", method = RequestMethod.GET)
	public String toHouseProperty(@RequestParam(value = "hid") Integer hid,
			@RequestParam(value = "change", required = false) String change,
			@RequestParam(value = "action", required = false) String action, HttpServletRequest request, Model model) {
		request.setAttribute("hid", hid);
		if (hid != null && action != null) {
			try {
				HouseProperty houseProperty = houseService.getHouseProperty(hid);
				String renovation = houseProperty.getRenovation();
				if (renovation.trim().equals("欧美风格")) {
					renovation = "1";
				} else if (renovation.trim().equals("现代简约")) {
					renovation = "2";
				} else if (renovation.trim().equals("中式风格")) {
					renovation = "3";
				} else if (renovation.trim().equals("田园风格")) {
					renovation = "4";
				} else if (renovation.trim().equals("巴洛克")) {
					renovation = "5";
				}
				String ac = houseProperty.getAc();
				if (ac.trim().equals("挂壁式空调")) {
					ac = "1";
				} else if (ac.trim().equals("立柜式空调")) {
					ac = "2";
				} else if (ac.trim().equals("窗式空调")) {
					ac = "3";
				} else if (ac.trim().equals("吊顶式空调")) {
					ac = "4";
				}
				String enclosure = houseProperty.getEnclosure();
				if (enclosure.trim().equals("锌钢护栏")) {
					enclosure = "1";
				} else if (enclosure.trim().equals("铁艺防护栏")) {
					enclosure = "2";
				} else if (enclosure.trim().equals("不锈钢护栏")) {
					enclosure = "3";
				} else if (enclosure.trim().equals("防腐木防护栏")) {
					enclosure = "4";
				} else if (enclosure.trim().equals("隐形钢丝防护栏")) {
					enclosure = "5";
				}
				String buildingStructure = houseProperty.getBuildingStructure();
				if (buildingStructure.trim().equals("砖木")) {
					buildingStructure = "1";
				} else if (buildingStructure.trim().equals("砖混")) {
					buildingStructure = "2";
				} else if (buildingStructure.trim().equals("钢筋混凝土")) {
					buildingStructure = "3";
				}
				String floor = houseProperty.getFloor();
				if (floor.trim().equals("实木地板")) {
					floor = "1";
				} else if (floor.trim().equals("实木复合地板")) {
					floor = "2";
				} else if (floor.trim().equals("强化木地板")) {
					floor = "3";
				} else if (floor.trim().equals("竹地板")) {
					floor = "4";
				} else if (floor.trim().equals("瓷砖地板")) {
					floor = "5";
				}
				String heating = houseProperty.getHeating();
				if (heating.trim().equals("暖气片")) {
					heating = "1";
				} else if (heating.trim().equals("地暖")) {
					heating = "2";
				} else if (heating.trim().equals("壁挂炉")) {
					heating = "3";
				} else if (heating.trim().equals("空调供暖")) {
					heating = "4";
				}
				String orientations = houseProperty.getOrientations();
				if (orientations.trim().equals("东")) {
					orientations = "1";
				} else if (orientations.trim().equals("西")) {
					orientations = "2";
				} else if (orientations.trim().equals("南")) {
					orientations = "3";
				} else if (orientations.trim().equals("北")) {
					orientations = "4";
				} else if (orientations.trim().equals("东南")) {
					orientations = "5";
				} else if (orientations.trim().equals("西南")) {
					orientations = "6";
				} else if (orientations.trim().equals("东北")) {
					orientations = "7";
				} else if (orientations.trim().equals("西北")) {
					orientations = "8";
				}
				model.addAttribute("orientations", Integer.parseInt(orientations));
				model.addAttribute("heating", Integer.parseInt(heating));
				model.addAttribute("floor", Integer.parseInt(floor));
				model.addAttribute("buildingStructure", Integer.parseInt(buildingStructure));
				model.addAttribute("enclosure", Integer.parseInt(enclosure));
				model.addAttribute("ac", Integer.parseInt(ac));
				model.addAttribute("renovation", Integer.parseInt(renovation));
				model.addAttribute(houseProperty);
				request.setAttribute("action", "change");
				if (change != null) {
					request.setAttribute("hint", "changepro");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			request.setAttribute("action", "add");
		}
		return "backend/houseproperty";
	}

	@RequestMapping(value = "/houseproperty", method = RequestMethod.POST)
	public String saveHousePropertyAndPicture(@ModelAttribute HouseProperty houseProperty,
			@RequestParam(value = "hid", required = false) Integer hid, HttpSession session, HttpServletRequest request,
			@RequestParam(value = "file-zh[]", required = true) MultipartFile[] imgList) {

		try {
			if (hid == null) {
				hid = houseService.getHouseMaxId();
			}
			// 判断用户有没有上传照片
			if (imgList != null && imgList.length > 0) {
				for (MultipartFile img : imgList) {
					HousePicture housePicture = new HousePicture();
					if (img == imgList[0]) {
						housePicture.setIsCover(1);
					} else {
						housePicture.setIsCover(2);
					}
					// 原始文件名字
					String originalFilename = img.getOriginalFilename();
					// 判断文件是否是图片类型
					String extension = FilenameUtils.getExtension(originalFilename);
					if (extension.equalsIgnoreCase("jpg") || extension.equalsIgnoreCase("png")
							|| extension.equalsIgnoreCase("bmp") || extension.equalsIgnoreCase("gif")) {
						long size = img.getSize();
						String realPath = request.getServletContext().getRealPath("/statics/uploadfiles");
						// 重新命名文件
						String newFilename = System.currentTimeMillis() + new Random().nextInt(50000000) + "_House."
								+ extension;
						// 创建新的文件
						File dscFile = new File(realPath, newFilename);

						// 上传文件
						// 如果目标文件不存在就创建文件
						if (!dscFile.exists()) {
							dscFile.createNewFile();
						}
						img.transferTo(dscFile);
						// 补全图片的路径到实体类
						housePicture.setHouseId(hid);
						housePicture.setHouseLocPath(realPath + File.separator + newFilename);
						housePicture.setHousePicPath(
								request.getServletContext().getContextPath() + "/statics/uploadfiles/" + newFilename);
						houseService.housePictureAdd(housePicture);

					} else {
						// 不是图片
						request.setAttribute("fileError", "图片类型必须是JPG||PNG||BMP||GIF格式");
						return "backend/houseproperty";
					}

				}
			}
			houseProperty.setHouseId(hid);
			String renovation = houseProperty.getRenovation();
			if (Integer.parseInt(renovation) == 1) {
				renovation = "欧美风格";
			} else if (Integer.parseInt(renovation) == 2) {
				renovation = "现代简约";
			} else if (Integer.parseInt(renovation) == 3) {
				renovation = "中式风格";
			} else if (Integer.parseInt(renovation) == 4) {
				renovation = "田园风格";
			} else if (Integer.parseInt(renovation) == 5) {
				renovation = "巴洛克";
			}
			houseProperty.setRenovation(renovation);
			String ac = houseProperty.getAc();
			if (Integer.parseInt(ac) == 1) {
				ac = "挂壁式空调";
			} else if (Integer.parseInt(ac) == 2) {
				ac = "立柜式空调";
			} else if (Integer.parseInt(ac) == 3) {
				ac = "窗式空调";
			} else if (Integer.parseInt(ac) == 4) {
				ac = "吊顶式空调";
			}
			houseProperty.setAc(ac);
			String enclosure = houseProperty.getEnclosure();
			if (Integer.parseInt(enclosure) == 1) {
				enclosure = "锌钢护栏";
			} else if (Integer.parseInt(enclosure) == 2) {
				enclosure = "铁艺防护栏";
			} else if (Integer.parseInt(enclosure) == 3) {
				enclosure = "不锈钢护栏";
			} else if (Integer.parseInt(enclosure) == 4) {
				enclosure = "防腐木防护栏";
			} else if (Integer.parseInt(enclosure) == 5) {
				enclosure = "隐形钢丝防护栏";
			}
			houseProperty.setEnclosure(enclosure);
			String buildingStructure = houseProperty.getBuildingStructure();
			if (Integer.parseInt(buildingStructure) == 1) {
				buildingStructure = "砖木";
			} else if (Integer.parseInt(buildingStructure) == 2) {
				buildingStructure = "砖混";
			} else if (Integer.parseInt(buildingStructure) == 3) {
				buildingStructure = "钢筋混凝土";
			}
			houseProperty.setBuildingStructure(buildingStructure);
			String floor = houseProperty.getFloor();
			if (Integer.parseInt(floor) == 1) {
				floor = "实木地板";
			} else if (Integer.parseInt(floor) == 2) {
				floor = "实木复合地板";
			} else if (Integer.parseInt(floor) == 3) {
				floor = "强化木地板";
			} else if (Integer.parseInt(floor) == 4) {
				floor = "竹地板";
			} else if (Integer.parseInt(floor) == 5) {
				floor = "瓷砖地板";
			}
			houseProperty.setFloor(floor);
			String heating = houseProperty.getHeating();
			if (Integer.parseInt(heating) == 1) {
				heating = "暖气片";
			} else if (Integer.parseInt(heating) == 2) {
				heating = "地暖";
			} else if (Integer.parseInt(heating) == 3) {
				heating = "壁挂炉";
			} else if (Integer.parseInt(heating) == 4) {
				heating = "空调供暖";
			}
			houseProperty.setHeating(heating);
			String orientations = houseProperty.getOrientations();
			if (Integer.parseInt(orientations) == 1) {
				orientations = "东";
			} else if (Integer.parseInt(orientations) == 2) {
				orientations = "西";
			} else if (Integer.parseInt(orientations) == 3) {
				orientations = "南";
			} else if (Integer.parseInt(orientations) == 4) {
				orientations = "北";
			} else if (Integer.parseInt(orientations) == 5) {
				orientations = "东南";
			} else if (Integer.parseInt(orientations) == 6) {
				orientations = "西南";
			} else if (Integer.parseInt(orientations) == 7) {
				orientations = "东北";
			} else if (Integer.parseInt(orientations) == 8) {
				orientations = "西北";
			}
			houseProperty.setOrientations(orientations);
			houseService.housePropertyAdd(houseProperty);
			request.setAttribute("hint", "successproperty");
		} catch (Exception e) {
			request.setAttribute("hint", "error");
			e.printStackTrace();
			return "backend/houseproperty";
		}
		return "redirect:houses?result=addsuccess";
	}

	@RequestMapping(value = "/changehouseproperty", method = RequestMethod.POST)
	public String changeHouseProperty(@ModelAttribute HouseProperty houseProperty) {
		String renovation = houseProperty.getRenovation();
		if (Integer.parseInt(renovation) == 1) {
			renovation = "欧美风格";
		} else if (Integer.parseInt(renovation) == 2) {
			renovation = "现代简约";
		} else if (Integer.parseInt(renovation) == 3) {
			renovation = "中式风格";
		} else if (Integer.parseInt(renovation) == 4) {
			renovation = "田园风格";
		} else if (Integer.parseInt(renovation) == 5) {
			renovation = "巴洛克";
		}
		houseProperty.setRenovation(renovation);
		String ac = houseProperty.getAc();
		if (Integer.parseInt(ac) == 1) {
			ac = "挂壁式空调";
		} else if (Integer.parseInt(ac) == 2) {
			ac = "立柜式空调";
		} else if (Integer.parseInt(ac) == 3) {
			ac = "窗式空调";
		} else if (Integer.parseInt(ac) == 4) {
			ac = "吊顶式空调";
		}
		houseProperty.setAc(ac);
		String enclosure = houseProperty.getEnclosure();
		if (Integer.parseInt(enclosure) == 1) {
			enclosure = "锌钢护栏";
		} else if (Integer.parseInt(enclosure) == 2) {
			enclosure = "铁艺防护栏";
		} else if (Integer.parseInt(enclosure) == 3) {
			enclosure = "不锈钢护栏";
		} else if (Integer.parseInt(enclosure) == 4) {
			enclosure = "防腐木防护栏";
		} else if (Integer.parseInt(enclosure) == 5) {
			enclosure = "隐形钢丝防护栏";
		}
		houseProperty.setEnclosure(enclosure);
		String buildingStructure = houseProperty.getBuildingStructure();
		if (Integer.parseInt(buildingStructure) == 1) {
			buildingStructure = "砖木";
		} else if (Integer.parseInt(buildingStructure) == 2) {
			buildingStructure = "砖混";
		} else if (Integer.parseInt(buildingStructure) == 3) {
			buildingStructure = "钢筋混凝土";
		}
		houseProperty.setBuildingStructure(buildingStructure);
		String floor = houseProperty.getFloor();
		if (Integer.parseInt(floor) == 1) {
			floor = "实木地板";
		} else if (Integer.parseInt(floor) == 2) {
			floor = "实木复合地板";
		} else if (Integer.parseInt(floor) == 3) {
			floor = "强化木地板";
		} else if (Integer.parseInt(floor) == 4) {
			floor = "竹地板";
		} else if (Integer.parseInt(floor) == 5) {
			floor = "瓷砖地板";
		}
		houseProperty.setFloor(floor);
		String heating = houseProperty.getHeating();
		if (Integer.parseInt(heating) == 1) {
			heating = "暖气片";
		} else if (Integer.parseInt(heating) == 2) {
			heating = "地暖";
		} else if (Integer.parseInt(heating) == 3) {
			heating = "壁挂炉";
		} else if (Integer.parseInt(heating) == 4) {
			heating = "空调供暖";
		}
		houseProperty.setHeating(heating);
		String orientations = houseProperty.getOrientations();
		if (Integer.parseInt(orientations) == 1) {
			orientations = "东";
		} else if (Integer.parseInt(orientations) == 2) {
			orientations = "西";
		} else if (Integer.parseInt(orientations) == 3) {
			orientations = "南";
		} else if (Integer.parseInt(orientations) == 4) {
			orientations = "北";
		} else if (Integer.parseInt(orientations) == 5) {
			orientations = "东南";
		} else if (Integer.parseInt(orientations) == 6) {
			orientations = "西南";
		} else if (Integer.parseInt(orientations) == 7) {
			orientations = "东北";
		} else if (Integer.parseInt(orientations) == 8) {
			orientations = "西北";
		}
		houseProperty.setOrientations(orientations);
		try {
			houseService.changeHousePropertyById(houseProperty);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Integer id = houseProperty.getHouseId();

		return "redirect:houseproperty?hid=" + id + "&&change=change&&action=change";
	}

	@RequestMapping(value = "/seachnobrokerhouses", method = RequestMethod.GET)
	public String seachNoBrokerHouses(
			@RequestParam(value = "pageIndex", required = false, defaultValue = "1") String pageIndex,
			HttpSession session, Model model) {
		List<HouseInfo> houses = null;
		HouseInfo houseInfo = new HouseInfo();
		;
		Integer pageSize = Constants.pageSize;
		PageSupport pageSupport = new PageSupport();
		try {
			houseInfo.setStatusId(1);
			int houseCount = houseService.getHouseInfoCount(houseInfo);
			houses = houseService.getHouseInfosByLimit(1, null, null, null, Integer.valueOf(pageIndex), pageSize);
			pageSupport.setCurrentPageNo(Integer.valueOf(pageIndex));
			pageSupport.setPageSize(pageSize);
			pageSupport.setTotalCount(houseCount);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("houses", houses);
		model.addAttribute("pages", pageSupport);
		return "backend/houselist";
	}

	@RequestMapping(value = "/seachhousesbybroker", method = RequestMethod.GET)
	public String seachHousesByBroker(@RequestParam("bid") Integer bid,
			@RequestParam(value = "pageIndex", required = false, defaultValue = "1") String pageIndex,
			HttpSession session, Model model) {
		List<HouseInfo> houses = null;
		HouseInfo houseInfo = new HouseInfo();
		Integer pageSize = Constants.pageSize;
		PageSupport pageSupport = new PageSupport();
		try {
			houseInfo.setBrokerId(bid);
			int houseCount = houseService.getHouseInfoCount(houseInfo);
			houses = houseService.getHouseInfosByLimit(null, bid, null, null, Integer.valueOf(pageIndex), pageSize);
			pageSupport.setCurrentPageNo(Integer.valueOf(pageIndex));
			pageSupport.setPageSize(pageSize);
			pageSupport.setTotalCount(houseCount);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("houses", houses);
		model.addAttribute("pages", pageSupport);
		return "backend/houselist";
	}

	@RequestMapping(value = "/addtraders", method = RequestMethod.GET)
	public String addTraders(@RequestParam("hid") Integer id, HttpServletRequest request) {
		request.setAttribute("hid", id);
		return "backend/tradersadd";
	}

	@RequestMapping(value = "/addtraders", method = RequestMethod.POST)
	public String addTraders(@RequestParam("hid") Integer id, @RequestParam("tradersName") String tradersName,
			@RequestParam("tradersPhone") String tradersPhone) {
		try {
			HouseInfo houseInfo = houseService.getHouseInfoById(id);
			houseInfo.setTradersName(tradersName);
			houseInfo.setTradersPhone(tradersPhone);
			houseService.changeHouseInfoById(houseInfo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "redirect:houses?result=traderssuccess";
	}

	@RequestMapping(value = "/delbrokers.json", method = RequestMethod.GET)
	@ResponseBody
	public String delbrokers(HttpServletRequest request) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		String items = request.getParameter("delitems");
		if (items == null || items == "") {
			resultMap.put("result", "failed");
		} else {
			String[] item = items.split(",");
			try {
				for (int i = 0; i < item.length; i++) {
					String fileLocPath = brokerInfoService
							.getBrokerInfo(null, null, Integer.valueOf(item[i]), null, null).getPortraitLocPath();
					File file = new File(fileLocPath);
					if (file.exists()) {
						file.delete();
					}
					brokerInfoService.deleteBrokerById(Integer.parseInt(item[i]));
				}
				resultMap.put("result", "success");
			} catch (Exception e) {
				resultMap.put("result", "failed");
				e.printStackTrace();
			}
		}
		return JSONArray.toJSONString(resultMap);
	}

	@RequestMapping(value = "/delbroker.json", method = RequestMethod.GET)
	@ResponseBody
	public String delbroker(@RequestParam("bid") Integer id) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		try {
			String fileLocPath = brokerInfoService.getBrokerInfo(null, null, id, null, null).getPortraitLocPath();
			File file = new File(fileLocPath);
			if (file.exists()) {
				file.delete();
			}
			brokerInfoService.deleteBrokerById(id);
			resultMap.put("result", "success");
		} catch (Exception e) {
			resultMap.put("result", "failed");
			e.printStackTrace();
		}
		return JSONArray.toJSONString(resultMap);
	}

	@RequestMapping(value = "/delusers.json", method = RequestMethod.GET)
	@ResponseBody
	public String delusers(HttpServletRequest request) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		String items = request.getParameter("delitems");
		if (items == null || items == "") {
			resultMap.put("result", "failed");
		} else {
			String[] item = items.split(",");
			try {
				for (int i = 0; i < item.length; i++) {
					List<Integer> houseids = houseService.getHouseIdByOwnerId(Integer.parseInt(item[i]));
					if (houseids != null) {
						for (Integer hid : houseids) {
							deleteHouse(hid);
						}
					}
					userService.delUserById(Integer.parseInt(item[i]));
				}
				resultMap.put("result", "success");
			} catch (Exception e) {
				resultMap.put("result", "failed");
				e.printStackTrace();
			}
		}
		return JSONArray.toJSONString(resultMap);
	}

	@RequestMapping(value = "/deluser.json", method = RequestMethod.GET)
	@ResponseBody
	public String deluser(@RequestParam("uid") Integer id) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		try {
			List<Integer> houseids = houseService.getHouseIdByOwnerId(id);
			if (houseids != null) {
				for (Integer hid : houseids) {
					deleteHouse(hid);
				}
			}
			userService.delUserById(id);
			resultMap.put("result", "success");
		} catch (Exception e) {
			resultMap.put("result", "failed");
			e.printStackTrace();
		}
		return JSONArray.toJSONString(resultMap);
	}

}
