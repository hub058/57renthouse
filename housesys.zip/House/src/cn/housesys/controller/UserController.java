package cn.housesys.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;

import cn.housesys.pojo.AddressProvince;
import cn.housesys.pojo.BrokerInfo;
import cn.housesys.pojo.UserInfo;
import cn.housesys.service.AddressService;
import cn.housesys.service.BrokerInfoService;
import cn.housesys.service.UserService;
import cn.housesys.tools.Constants;

@Controller
@RequestMapping("/user")
public class UserController {
	@Resource
	private UserService userService;
	@Resource
	private AddressService addressService;
	@Resource
	private BrokerInfoService brokerInfoService;

	int mobile_code = 0;
	String final_mobile = null;

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(@RequestParam(value = "email") String email, @RequestParam(value = "password") String password,
			Model model, HttpSession session, HttpServletRequest request) {
		List<AddressProvince> addressProvinces = null;
		UserInfo userInfo = null;
		BrokerInfo brokerInfo = null;
		try {
			addressProvinces = addressService.getProvinceList();
			userInfo = userService.login(email, password);
			brokerInfo = brokerInfoService.getBrokerInfo(email, password, null, null, null);
			if (userInfo != null || brokerInfo != null) {
				if (userInfo != null) {
					userInfo.setStatus(1);
					userService.changeUserInfo(userInfo);
					session.setAttribute(Constants.USER, userInfo);
				} else if (brokerInfo != null) {
					session.setAttribute(Constants.BROKER, brokerInfo);
				}
			} else {
				request.setAttribute("hint", "error");
			}

		} catch (Exception e2) {
			e2.printStackTrace();
		}
		model.addAttribute("provinceList", addressProvinces);
		return "main";
	}

	@RequestMapping(value = "/loginbytel", method = RequestMethod.POST)
	public String loginByTel(@RequestParam(value = "tel") String tel,
			@RequestParam(value = "verificationcode") int verificationcode, HttpSession session,
			HttpServletRequest request) {
		try {
			if (final_mobile.equals(tel)&&tel != null && tel != "" && mobile_code == verificationcode) {
				UserInfo userInfo = userService.getUserInfoByTel(tel);
				BrokerInfo brokerInfo = brokerInfoService.getBrokerInfo(null, null, null, null, tel);
				if (userInfo != null) {
					userInfo.setStatus(1);
					session.setAttribute(Constants.USER, userInfo);
				} else if (brokerInfo != null) {
					session.setAttribute(Constants.BROKER, brokerInfo);
				} else {
					request.setAttribute("hint", "none");
				}
			} else if(verificationcode != mobile_code){
				request.setAttribute("hint", "errorcode");
			}else if(!final_mobile.equals(tel)){
				request.setAttribute("hint", "difference");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "main";
	}

	@RequestMapping(value = "/regist", method = RequestMethod.POST)
	public String regist(@ModelAttribute UserInfo user, @RequestParam("verificationcode") int verificationcode,
			HttpSession session, HttpServletRequest request) {
		user.setStatus(0);
		user.setRoleId(2);
		user.setName("普通用户");
		user.setGender(1);
		user.setCreationDate(new Date());
		try {
			if (final_mobile.equals(user.getId())&&mobile_code == verificationcode) {
				userService.regist(user);
				request.setAttribute("hint", "success");
			} else if(verificationcode != mobile_code){
				request.setAttribute("hint", "errorcode");
			}else if(!final_mobile.equals(user.getTel())){
				request.setAttribute("hint", "difference");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "main";

	}

	@RequestMapping(value = "/forgot", method = RequestMethod.POST)
	public String forgot(@RequestParam("verificationcode") int verificationcode, @RequestParam("tel") String tel,
			@RequestParam("password") String password, HttpServletRequest request) {
		try {
			UserInfo userInfo = userService.getUserInfoByTel(tel);
			BrokerInfo brokerInfo = brokerInfoService.getBrokerInfo(null, null, null, null, tel);
			if (final_mobile.equals(tel)&&verificationcode == mobile_code) {
				if (userInfo != null) {
					userInfo.setModifyDate(new Date());
					userInfo.setPassword(password);
					userService.changeUserInfo(userInfo);
					request.setAttribute("hint", "forgotsuccess");
				} else if (brokerInfo != null) {
					brokerInfo.setPassword(password);
					brokerInfoService.changeBrokerInfo(brokerInfo);
					request.setAttribute("hint", "forgotsuccess");
				} else {
					request.setAttribute("hint", "none");
				}

			} else if(verificationcode != mobile_code){
				request.setAttribute("hint", "errorcode");
			}else if(!final_mobile.equals(tel)){
				request.setAttribute("hint", "difference");
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return "main";

	}

	@RequestMapping(value = "/logout")
	public String logout(HttpSession session) {
		UserInfo user = (UserInfo) session.getAttribute(Constants.USER);
		try {
			if (user != null) {
				user.setStatus(0);
				userService.changeUserInfo(user);
			}

			session.removeAttribute(Constants.USER);
			session.removeAttribute(Constants.BROKER);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "main";
	}

	@RequestMapping(value = "/telexist")
	@ResponseBody
	public Object telexist(@RequestParam("tel") String tel, HttpServletRequest request) {
		HashMap<String, String> resultMap = new HashMap<String, String>();
		try {
			UserInfo userInfo = userService.getUserInfoByTel(tel);
			BrokerInfo brokerInfo = brokerInfoService.getBrokerInfo(null, null, null, null, tel);
			if (userInfo == null && brokerInfo == null) {
				resultMap.put("result", "none");
			} else {
				resultMap.put("result", "exist");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return JSONArray.toJSONString(resultMap);
	}

	private static String Url = "http://106.ihuyi.cn/webservice/sms.php?method=Submit";

	@RequestMapping(value = "/message.json", method = RequestMethod.POST)
	@ResponseBody
	public Object message(@RequestParam(value = "mobile", required = false) String mobile) {
		final_mobile = mobile;
		HttpClient client = new HttpClient();
		PostMethod method = new PostMethod(Url);

		client.getParams().setContentCharset("GBK");
		method.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset=GBK");

		mobile_code = (int) ((Math.random() * 9 + 1) * 100000);
		System.out.println(mobile_code);

		String content = new String("您的验证码是：" + mobile_code + "。请不要把验证码泄露给其他人。");

		NameValuePair[] data = { // 提交短信
				new NameValuePair("account", "C96594779"), // 查看用户名是登录用户中心->验证码短信->产品总览->APIID
				new NameValuePair("password", "a4f2e6bfe502a2a1595b983bccf7d03d"), // 查看密码请登录用户中心->验证码短信->产品总览->APIKEY
				new NameValuePair("mobile", mobile), new NameValuePair("content", content), };
		method.setRequestBody(data);

		try {
			client.executeMethod(method);

			String SubmitResult = method.getResponseBodyAsString();

			// System.out.println(SubmitResult);

			Document doc = DocumentHelper.parseText(SubmitResult);
			Element root = doc.getRootElement();

			String code = root.elementText("code");
			String msg = root.elementText("msg");
			String smsid = root.elementText("smsid");

			System.out.println(code);
			System.out.println(msg);
			System.out.println(smsid);

			if ("2".equals(code)) {
				System.out.println("短信提交成功");
			}

		} catch (HttpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return JSONArray.toJSONString(mobile_code);
	}
}
