package cn.housesys.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONArray;

import cn.housesys.pojo.AddressArea;
import cn.housesys.pojo.AddressCity;
import cn.housesys.pojo.AddressProvince;
import cn.housesys.pojo.BrokerInfo;
import cn.housesys.pojo.HouseInfo;
import cn.housesys.pojo.HousePicture;
import cn.housesys.pojo.HouseProperty;
import cn.housesys.pojo.HouseStatus;
import cn.housesys.pojo.HouseType;
import cn.housesys.pojo.UserInfo;
import cn.housesys.service.AddressService;
import cn.housesys.service.BrokerInfoService;
import cn.housesys.service.HouseService;
import cn.housesys.tools.Constants;
import cn.housesys.tools.PageSupport;

@Controller
@RequestMapping(value = "/house")
public class HouseController {

	@Resource
	private HouseService houseService;
	@Resource
	private AddressService addressService;
	@Resource
	private BrokerInfoService brokerInfoService;

	@RequestMapping(value = "/tomain")
	public String toMain(HttpSession session, HttpServletRequest request, Model model) {
		List<AddressProvince> addressProvinces = null;
		List<HouseInfo> houseInfos = null;
		try {
			addressProvinces = addressService.getProvinceList();
			houseInfos = houseService.getHouseInfosByLimit(null, null, null, 1, 1, 6);
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("provinceList", addressProvinces);
		model.addAttribute("houseInfos", houseInfos);
		return "main";
	}

	@RequestMapping(value = "/houseinfo")
	public String toHouseInfo(@RequestParam(value = "hid", required = false) Integer id,
			@RequestParam(value = "change", required = false) String change, HttpSession session,
			HttpServletRequest request, Model model) {
		List<AddressProvince> addressProvinces = null;
		List<AddressCity> addressCities = null;
		List<AddressArea> addressAreas = null;
		HouseInfo houseInfo = null;
		try {
			addressProvinces = addressService.getProvinceList();
			if (id != null) {
				Boolean sskf = false;
				Boolean mw = false;
				Boolean wy = false;
				Boolean jzx = false;
				Boolean dtf = false;
				Boolean jtbl = false;
				Boolean hjym = false;
				Boolean shbg = false;
				houseInfo = houseService.getHouseInfoById(id);
				addressCities = addressService.getCityListByProCode(houseInfo.getProvince());
				addressAreas = addressService.getAreaListByCityCode(houseInfo.getCity());
				String[] item = houseInfo.getDescribe().split(",");
				for (String describe : item) {
					if (describe.equals("随时看房")) {
						sskf = true;
					} else if (describe.equals("满五")) {
						mw = true;
					} else if (describe.equals("唯一")) {
						wy = true;
					} else if (describe.equals("精装修")) {
						jzx = true;
					} else if (describe.equals("地铁房")) {
						dtf = true;
					} else if (describe.equals("交通便利")) {
						jtbl = true;
					} else if (describe.equals("环境优美")) {
						hjym = true;
					} else if (describe.equals("适合办公")) {
						shbg = true;
					}
				}
				model.addAttribute("p", houseInfo.getProvince());
				model.addAttribute("c", houseInfo.getCity());
				model.addAttribute("a", houseInfo.getArea());
				model.addAttribute("cityList", addressCities);
				model.addAttribute("areaList", addressAreas);
				model.addAttribute("sskf", sskf);
				model.addAttribute("mw", mw);
				model.addAttribute("wy", wy);
				model.addAttribute("jzx", jzx);
				model.addAttribute("dtf", dtf);
				model.addAttribute("jtbl", jtbl);
				model.addAttribute("hjym", hjym);
				model.addAttribute("shbg", shbg);
				model.addAttribute(houseInfo);
				request.setAttribute("action", "change");
				if (change != null) {
					request.setAttribute("hint", "change");
				}
			} else {
				request.setAttribute("action", "add");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("provinceList", addressProvinces);
		return "backend/houseinfo";
	}

	@RequestMapping(value = "/changehouseinfo", method = RequestMethod.POST)
	public String changeHouseInfo(@ModelAttribute HouseInfo houseInfo,
			@RequestParam(value = "queryMw", required = false) String queryMw,
			@RequestParam(value = "querySskf", required = false) String querySskf,
			@RequestParam(value = "queryWy", required = false) String queryWy,
			@RequestParam(value = "queryJzx", required = false) String queryJzx,
			@RequestParam(value = "queryDtf", required = false) String queryDtf,
			@RequestParam(value = "queryJtbl", required = false) String queryJtbl,
			@RequestParam(value = "queryHjym", required = false) String queryHjym,
			@RequestParam(value = "queryShbg", required = false) String queryShbg, HttpServletRequest request) {
		StringBuffer describe = new StringBuffer();
		if (queryMw != null) {
			describe.append("满五,");
		}
		if (querySskf != null) {
			describe.append("随时看房,");
		}
		if (queryWy != null) {
			describe.append("唯一,");
		}
		if (queryJzx != null) {
			describe.append("精装修,");
		}
		if (queryDtf != null) {
			describe.append("地铁房,");
		}
		if (queryJtbl != null) {
			describe.append("交通便利,");
		}
		if (queryHjym != null) {
			describe.append("环境优美,");
		}
		if (queryShbg != null) {
			describe.append("适合办公,");
		}
		describe.append(
				houseInfo.getRoomNum() + "室" + houseInfo.getParlourNum() + "厅" + houseInfo.getGarageNum() + "车位");
		houseInfo.setDescribe(describe.toString());
		houseInfo.setStatusId(1);
		try {
			houseService.changeHouseInfoById(houseInfo);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Integer id = houseInfo.getId();
		return "redirect:houseinfo?change=change&&hid=" + id;
	}

	@RequestMapping(value = "/cityList.json", method = RequestMethod.GET)
	@ResponseBody
	public Object getCities(@RequestParam String provincecode) {
		List<AddressCity> addressCities = null;
		if ("".equals(provincecode))
			provincecode = null;
		try {
			if (provincecode == null) {
				addressCities = addressService.getCityListByProCode("0");
			} else {
				addressCities = addressService.getCityListByProCode(provincecode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return JSONArray.toJSONString(addressCities);
	}

	@RequestMapping(value = "/areaList.json", method = RequestMethod.GET)
	@ResponseBody
	public Object getAreas(@RequestParam String citycode) {
		List<AddressArea> addressAreas = null;
		if ("".equals(citycode))
			citycode = null;
		try {
			if (citycode == null) {
				addressAreas = addressService.getAreaListByCityCode("0");
			} else {
				addressAreas = addressService.getAreaListByCityCode(citycode);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return JSONArray.toJSONString(addressAreas);
	}

	@RequestMapping(value = "/houselist", method = RequestMethod.GET)
	public String getHouseInfosByStatusId(@RequestParam(value = "houseStatus", required = false) String statusId,
			@RequestParam(value = "province", required = false) String province,
			@RequestParam(value = "city", required = false) String city,
			@RequestParam(value = "area", required = false) String area,
			@RequestParam(value = "houseType", required = false) String typeId,
			@RequestParam(value = "roomNum", required = false) String roomNum,
			@RequestParam(value = "maxPrice", required = false) String price,
			@RequestParam(value = "ownerId", required = false) String ownerId,
			@RequestParam(value = "pageIndex", required = false, defaultValue = "1") String pageIndex, Model model) {
		List<HouseInfo> houseInfoList = null;
		List<AddressProvince> provinceList = null;
		List<AddressCity> cityList = null;
		List<AddressArea> areaList = null;
		List<HouseType> houseType = null;
		HouseInfo houseInfo = new HouseInfo();
		if (statusId != null && statusId != "") {
			houseInfo.setStatusId(Integer.valueOf(statusId));
		}
		if (typeId != null && typeId != "") {
			houseInfo.setTypeId(Integer.valueOf(typeId));
		}
		if (roomNum != null && roomNum != "") {
			houseInfo.setRoomNum(Integer.valueOf(roomNum));
		}
		if (price != null && price != "") {
			houseInfo.setPrice(Float.valueOf(price));
		}
		if (ownerId != null && ownerId != "") {
			houseInfo.setOwnerId(Integer.valueOf(ownerId));
		}
		if (province != null && province != "") {
			houseInfo.setProvince(province);
			try {
				cityList = addressService.getCityListByProCode(province);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (city != null && city != "") {
			houseInfo.setCity(city);
			try {
				areaList = addressService.getAreaListByCityCode(city);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (area != null && area != "") {
			houseInfo.setArea(area);
		}
		int currentPageNo = 1;
		if (pageIndex != null) {
			currentPageNo = Integer.parseInt(pageIndex);
		}
		Integer pageSize = Constants.pageSize;
		Integer houseCount = 0;
		try {
			houseCount = houseService.getHouseInfoCount(houseInfo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		PageSupport pageSupport = new PageSupport();
		pageSupport.setCurrentPageNo(currentPageNo);
		pageSupport.setPageSize(pageSize);
		pageSupport.setTotalCount(houseCount);
		try {
			houseInfoList = houseService.getHouseInfos(houseInfo, null, currentPageNo, pageSize);
			houseType = houseService.getHouseType();
			provinceList = addressService.getProvinceList();
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("houseInfoList", houseInfoList);
		model.addAttribute("provinceList", provinceList);
		model.addAttribute("cityList", cityList);
		model.addAttribute("areaList", areaList);
		model.addAttribute("pages", pageSupport);
		model.addAttribute("province", province);
		model.addAttribute("houseStatus", statusId);
		model.addAttribute("houseTypeList", houseType);
		model.addAttribute("houseType", typeId);
		model.addAttribute("city", city);
		model.addAttribute("area", area);
		model.addAttribute("roomNum", roomNum);
		model.addAttribute("maxPrice", price);
		model.addAttribute("ownerId", ownerId);
		return "houselist";
	}

	@RequestMapping(value = "/houseview", method = RequestMethod.GET)
	public String getHouseView(@RequestParam(value = "houseId") String houseId, Model model, HttpSession session) {
		HouseInfo houseInfo = null;
		HouseProperty houseProperty = null;
		List<HousePicture> housePictures = null;
		BrokerInfo brokerInfo = null;
		List<HouseInfo> nearHouses = null;
		try {
			houseInfo = houseService.getHouseInfoById(Integer.valueOf(houseId));
			houseProperty = houseService.getHouseProperty(Integer.valueOf(houseId));
			housePictures = houseService.getHousePictures(Integer.valueOf(houseId), 1, 4);
			brokerInfo = brokerInfoService.getBrokerInfo(null, null, houseInfo.getBrokerId(), null,null);
			HouseInfo house = new HouseInfo();
			house.setArea(houseInfo.getArea());
			house.setStatusId(houseInfo.getStatusId());
			house.setId(houseInfo.getId());
			nearHouses = houseService.getHouseInfos(house, houseProperty.getStreet(), 1, 3);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("houseInfo", houseInfo);
		model.addAttribute("houseProperty", houseProperty);
		model.addAttribute("housePictures", housePictures);
		model.addAttribute("brokerInfo", brokerInfo);
		model.addAttribute("nearHouses", nearHouses);
		return "houseview";
	}

	@RequestMapping(value = "/about", method = RequestMethod.GET)
	public String aboutus() {
		return "about";
	}

	@RequestMapping(value = "/service", method = RequestMethod.GET)
	public String service() {
		return "services";
	}

	@RequestMapping(value = "/notice", method = RequestMethod.GET)
	public String notice() {
		return "notice";
	}

	@RequestMapping(value = "/privacystatement", method = RequestMethod.GET)
	public String privacystatement() {
		return "privacystatement";
	}

	@RequestMapping(value = "/housepictures", method = RequestMethod.GET)
	public String housePictures(@RequestParam("hid") Integer hid,
			@RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex, Model model) {
		Integer pageSize = Constants.pageSize;
		try {
			Integer housePictureCount = houseService.getHousePictureCountByHid(hid);
			List<HousePicture> housePictures = houseService.getHousePictures(hid, pageIndex, pageSize);
			PageSupport pageSupport = new PageSupport();
			pageSupport.setCurrentPageNo(pageIndex);
			pageSupport.setPageSize(pageSize);
			pageSupport.setTotalCount(housePictureCount);
			model.addAttribute("pictures", housePictures);
			model.addAttribute("pages", pageSupport);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "housepicture";
	}

	@RequestMapping(value = "/brokers", method = RequestMethod.GET)
	public String getBrokers(@RequestParam(value = "pageIndex", required = false, defaultValue = "1") Integer pageIndex,
			Model model) {
		try {
			Integer brokerCount = brokerInfoService.getBrokerCount(null, null);
			Integer pageSize = Constants.pageSize;
			PageSupport pageSupport = new PageSupport();
			pageSupport.setCurrentPageNo(pageIndex);
			pageSupport.setPageSize(pageSize);
			pageSupport.setTotalCount(brokerCount);
			List<BrokerInfo> brokerInfos = brokerInfoService.findall(null, null, pageIndex, pageSize);
			model.addAttribute("brokerlist", brokerInfos);
			model.addAttribute("pages", pageSupport);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "brokers";
	}
     @RequestMapping(value="/broker",method=RequestMethod.GET)
	public String getBrokerById(@RequestParam("bid") Integer bid, Model model) {
		try {
			BrokerInfo brokerInfo = brokerInfoService.getBrokerInfo(null, null, bid, null,null);
			model.addAttribute("broker", brokerInfo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "broker";
	}

}
